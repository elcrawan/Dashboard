// Excel Data Synchronization System
// Advanced Excel import/export with real-time updates

class ExcelSyncSystem {
    constructor() {
        this.workers = new Map();
        this.syncHistory = [];
        this.conflictResolver = new ConflictResolver();
    }

    // Excel Import System
    async importExcelData(file) {
        try {
            const data = await this.parseExcelFile(file);
            const validation = await this.validateData(data);
            
            if (validation.isValid) {
                const processedData = await this.processData(data);
                await this.syncWithDatabase(processedData);
                this.logSync('import', file.name, processedData.length);
                return { success: true, count: processedData.length };
            } else {
                return { success: false, errors: validation.errors };
            }
        } catch (error) {
            console.error('Excel import error:', error);
            return { success: false, error: error.message };
        }
    }

    async parseExcelFile(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = (e) => {
                try {
                    const data = new Uint8Array(e.target.result);
                    const workbook = XLSX.read(data, { type: 'array' });
                    const sheetName = workbook.SheetNames[0];
                    const worksheet = workbook.Sheets[sheetName];
                    const jsonData = XLSX.utils.sheet_to_json(worksheet);
                    resolve(jsonData);
                } catch (error) {
                    reject(error);
                }
            };
            reader.readAsArrayBuffer(file);
        });
    }

    async validateData(data) {
        const errors = [];
        const requiredFields = ['project_name', 'budget', 'start_date', 'status'];
        
        data.forEach((row, index) => {
            requiredFields.forEach(field => {
                if (!row[field]) {
                    errors.push(`الصف ${index + 2}: حقل ${field} مطلوب`);
                }
            });
            
            if (row.budget && isNaN(parseFloat(row.budget))) {
                errors.push(`الصف ${index + 2}: الميزانية يجب أن تكون رقم`);
            }
        });

        return { isValid: errors.length === 0, errors };
    }

    async processData(data) {
        return data.map(row => ({
            projectName: row.project_name,
            budget: parseFloat(row.budget),
            startDate: new Date(row.start_date),
            endDate: row.end_date ? new Date(row.end_date) : null,
            status: row.status,
            type: row.type || 'general',
            client: row.client || '',
            location: row.location || '',
            description: row.description || ''
        }));
    }

    // Excel Export System
    async exportToExcel(dataType, filters = {}) {
        const data = await this.fetchData(dataType, filters);
        const workbook = XLSX.utils.book_new();
        
        const worksheet = XLSX.utils.json_to_sheet(data);
        XLSX.utils.book_append_sheet(workbook, worksheet, dataType);
        
        const filename = `${dataType}_${new Date().toISOString().split('T')[0]}.xlsx`;
        XLSX.writeFile(workbook, filename);
        
        this.logSync('export', filename, data.length);
    }

    async fetchData(dataType, filters) {
        // Fetch data based on type and filters
        const dataMap = {
            'projects': () => this.getProjectsData(filters),
            'tenders': () => this.getTendersData(filters),
            'financial': () => this.getFinancialData(filters),
            'progress': () => this.getProgressData(filters)
        };

        return dataMap[dataType] ? dataMap[dataType]() : [];
    }

    // Real-time Sync System
    setupAutoSync() {
        // Watch for file changes in designated folder
        if ('FileSystemObserver' in window) {
            const observer = new FileSystemObserver((records) => {
                records.forEach(record => {
                    if (record.type === 'modified') {
                        this.handleFileChange(record.file);
                    }
                });
            });
            
            // Start observing
            observer.observe(this.getSyncFolder());
        }
    }

    async handleFileChange(file) {
        const lastSync = this.getLastSyncTime(file.name);
        const fileModified = await file.lastModified;
        
        if (fileModified > lastSync) {
            await this.importExcelData(file);
            this.updateLastSyncTime(file.name, fileModified);
        }
    }

    // Conflict Resolution
    async resolveConflicts(localData, remoteData) {
        const conflicts = [];
        
        localData.forEach(localItem => {
            const remoteItem = remoteData.find(r => r.id === localItem.id);
            if (remoteItem && localItem.lastModified !== remoteItem.lastModified) {
                conflicts.push({
                    id: localItem.id,
                    local: localItem,
                    remote: remoteItem,
                    type: this.detectConflictType(localItem, remoteItem)
                });
            }
        });

        return await this.conflictResolver.resolve(conflicts);
    }

    // Data Validation Engine
    validateFinancialData(data) {
        const rules = {
            budget: (value) => value > 0 && value < 1000000000,
            start_date: (value) => new Date(value) <= new Date(),
            end_date: (value, row) => new Date(value) > new Date(row.start_date),
            status: (value) => ['planning', 'active', 'completed', 'cancelled'].includes(value)
        };

        const errors = [];
        data.forEach((row, index) => {
            Object.keys(rules).forEach(field => {
                if (!rules[field](row[field], row)) {
                    errors.push(`الصف ${index + 2}: ${field} غير صالح`);
                }
            });
        });

        return errors;
    }

    // Backup System
    async createBackup() {
        const timestamp = new Date().toISOString();
        const backupData = {
            timestamp,
            projects: await this.getAllProjects(),
            tenders: await this.getAllTenders(),
            financial: await this.getAllFinancialData(),
            settings: await this.getSettings()
        };

        const blob = new Blob([JSON.stringify(backupData, null, 2)], 
            { type: 'application/json' });
        
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `backup_${timestamp}.json`;
        a.click();
        
        this.logSync('backup', 'full_backup', Object.keys(backupData).length);
    }

    // Utility Methods
    logSync(type, filename, count) {
        const log = {
            type,
            filename,
            count,
            timestamp: new Date().toISOString(),
            user: this.getCurrentUser()
        };
        
        this.syncHistory.unshift(log);
        if (this.syncHistory.length > 100) {
            this.syncHistory = this.syncHistory.slice(0, 100);
        }
        
        localStorage.setItem('sync_history', JSON.stringify(this.syncHistory));
    }

    getSyncHistory() {
        return JSON.parse(localStorage.getItem('sync_history') || '[]');
    }

    getCurrentUser() {
        return localStorage.getItem('current_user') || 'anonymous';
    }

    // Advanced Features
    async scheduleSync(cronExpression) {
        // Schedule automatic sync using cron-like syntax
        const cron = this.parseCronExpression(cronExpression);
        
        setInterval(() => {
            if (this.shouldRunSync(cron)) {
                this.performScheduledSync();
            }
        }, 60000); // Check every minute
    }

    async performScheduledSync() {
        const pendingFiles = await this.getPendingFiles();
        
        for (const file of pendingFiles) {
            await this.importExcelData(file);
        }
    }

    // Data Transformation Engine
    transformData(data, transformationRules) {
        return data.map(row => {
            const transformed = { ...row };
            
            transformationRules.forEach(rule => {
                if (rule.type === 'calculate') {
                    transformed[rule.target] = rule.formula(row);
                } else if (rule.type === 'format') {
                    transformed[rule.target] = rule.formatter(row[rule.source]);
                } else if (rule.type === 'map') {
                    transformed[rule.target] = rule.mapping[row[rule.source]];
                }
            });
            
            return transformed;
        });
    }
}

// Conflict Resolver Class
class ConflictResolver {
    async resolve(conflicts) {
        const resolved = [];
        
        for (const conflict of conflicts) {
            const resolution = await this.resolveConflict(conflict);
            resolved.push(resolution);
        }
        
        return resolved;
    }

    async resolveConflict(conflict) {
        // AI-powered conflict resolution
        const strategies = {
            'timestamp': () => this.resolveByTimestamp(conflict),
            'user_priority': () => this.resolveByUserPriority(conflict),
            'manual': () => this.resolveManually(conflict),
            'merge': () => this.resolveByMerge(conflict)
        };

        const strategy = this.selectStrategy(conflict);
        return strategies[strategy](conflict);
    }

    selectStrategy(conflict) {
        // Logic to select best resolution strategy
        if (conflict.type === 'simple_update') {
            return 'timestamp';
        } else if (conflict.type === 'complex_update') {
            return 'merge';
        } else {
            return 'manual';
        }
    }

    resolveByTimestamp(conflict) {
        return conflict.local.lastModified > conflict.remote.lastModified 
            ? conflict.local 
            : conflict.remote;
    }

    resolveByMerge(conflict) {
        // Merge non-conflicting fields
        return { ...conflict.remote, ...conflict.local };
    }

    resolveManually(conflict) {
        // Prompt user for resolution
        return new Promise(resolve => {
            // UI for manual resolution
            resolve(conflict.local); // Default to local
        });
    }
}

// Initialize Excel Sync System
const excelSync = new ExcelSyncSystem();

// Global functions for UI
function importExcel() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.xlsx,.xls';
    input.onchange = async (e) => {
        const file = e.target.files[0];
        const result = await excelSync.importExcelData(file);
        
        if (result.success) {
            alert(`تم استيراد ${result.count} سجل بنجاح`);
            location.reload();
        } else {
            alert('خطأ في الاستيراد: ' + (result.error || result.errors.join(', ')));
        }
    };
    input.click();
}

function exportExcel(type) {
    excelSync.exportToExcel(type);
}

function createBackup() {
    excelSync.createBackup();
}

// Setup auto-sync
document.addEventListener('DOMContentLoaded', () => {
    excelSync.setupAutoSync();
});