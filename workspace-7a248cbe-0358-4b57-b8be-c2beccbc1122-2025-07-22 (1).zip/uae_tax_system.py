#!/usr/bin/env python3
"""
UAE Tax System Implementation
Handles VAT 5%, Income Tax 9%, and other UAE tax requirements
"""

import json
import csv
import random
from datetime import datetime, timedelta
from decimal import Decimal

class UAETaxSystem:
    def __init__(self):
        self.vat_rate = Decimal('0.05')  # 5% VAT
        self.income_tax_rate = Decimal('0.09')  # 9% Income Tax
        
    def calculate_vat(self, amount, is_vat_inclusive=False):
        """Calculate VAT amount"""
        if is_vat_inclusive:
            vat_amount = amount * self.vat_rate / (1 + self.vat_rate)
            net_amount = amount - vat_amount
        else:
            vat_amount = amount * self.vat_rate
            net_amount = amount
            
        return {
            'gross_amount': float(amount),
            'vat_amount': float(vat_amount),
            'net_amount': float(net_amount),
            'vat_rate': float(self.vat_rate)
        }
    
    def calculate_income_tax(self, taxable_income):
        """Calculate income tax based on UAE tax law"""
        # UAE corporate tax is 9% on profits above AED 375,000
        tax_threshold = Decimal('375000')
        
        if taxable_income <= tax_threshold:
            return {
                'taxable_income': float(taxable_income),
                'tax_amount': 0.0,
                'tax_rate': 0.0,
                'exempt_amount': float(tax_threshold)
            }
        else:
            taxable_amount = taxable_income - tax_threshold
            tax_amount = taxable_amount * self.income_tax_rate
            
            return {
                'taxable_income': float(taxable_income),
                'tax_amount': float(tax_amount),
                'tax_rate': float(self.income_tax_rate),
                'exempt_amount': float(tax_threshold),
                'taxable_base': float(taxable_amount)
            }
    
    def generate_vat_return(self, transactions, period):
        """Generate VAT return for a specific period"""
        vat_on_sales = Decimal('0')
        vat_on_expenses = Decimal('0')
        total_sales = Decimal('0')
        total_expenses = Decimal('0')
        
        for transaction in transactions:
            if transaction['period'] == period:
                if transaction['type'] == 'sales':
                    vat_calc = self.calculate_vat(Decimal(str(transaction['amount'])))
                    vat_on_sales += Decimal(str(vat_calc['vat_amount']))
                    total_sales += Decimal(str(transaction['amount']))
                elif transaction['type'] == 'expenses':
                    vat_calc = self.calculate_vat(Decimal(str(transaction['amount'])))
                    vat_on_expenses += Decimal(str(vat_calc['vat_amount']))
                    total_expenses += Decimal(str(transaction['amount']))
        
        net_vat_payable = vat_on_sales - vat_on_expenses
        
        return {
            'period': period,
            'vat_on_sales': float(vat_on_sales),
            'vat_on_expenses': float(vat_on_expenses),
            'net_vat_payable': float(net_vat_payable),
            'total_sales': float(total_sales),
            'total_expenses': float(total_expenses),
            'filing_date': datetime.now().strftime('%Y-%m-%d'),
            'payment_due_date': (datetime.now() + timedelta(days=28)).strftime('%Y-%m-%d')
        }
    
    def generate_income_tax_return(self, financial_data, tax_year):
        """Generate income tax return"""
        total_revenue = Decimal(str(financial_data.get('total_revenue', 0)))
        total_expenses = Decimal(str(financial_data.get('total_expenses', 0)))
        taxable_income = total_revenue - total_expenses
        
        tax_calc = self.calculate_income_tax(taxable_income)
        
        return {
            'tax_year': tax_year,
            'total_revenue': float(total_revenue),
            'total_expenses': float(total_expenses),
            'taxable_income': float(taxable_income),
            'tax_amount': tax_calc['tax_amount'],
            'tax_rate': tax_calc['tax_rate'],
            'filing_date': datetime.now().strftime('%Y-%m-%d'),
            'payment_due_date': (datetime.now() + timedelta(days=90)).strftime('%Y-%m-%d')
        }
    
    def calculate_financial_ratios(self, balance_sheet, income_statement):
        """Calculate comprehensive financial ratios"""
        ratios = {}
        
        # Liquidity Ratios
        current_assets = Decimal(str(balance_sheet.get('current_assets', 0)))
        current_liabilities = Decimal(str(balance_sheet.get('current_liabilities', 0)))
        inventory = Decimal(str(balance_sheet.get('inventory', 0)))
        
        ratios['current_ratio'] = float(current_assets / current_liabilities) if current_liabilities > 0 else 0
        ratios['quick_ratio'] = float((current_assets - inventory) / current_liabilities) if current_liabilities > 0 else 0
        
        # Leverage Ratios
        total_debt = Decimal(str(balance_sheet.get('total_debt', 0)))
        total_equity = Decimal(str(balance_sheet.get('total_equity', 0)))
        total_assets = Decimal(str(balance_sheet.get('total_assets', 0)))
        
        ratios['debt_to_equity'] = float(total_debt / total_equity) if total_equity > 0 else 0
        ratios['debt_to_assets'] = float(total_debt / total_assets) if total_assets > 0 else 0
        
        # Profitability Ratios
        net_income = Decimal(str(income_statement.get('net_income', 0)))
        revenue = Decimal(str(income_statement.get('revenue', 0)))
        gross_profit = Decimal(str(income_statement.get('gross_profit', 0)))
        
        ratios['gross_margin'] = float(gross_profit / revenue * 100) if revenue > 0 else 0
        ratios['net_margin'] = float(net_income / revenue * 100) if revenue > 0 else 0
        ratios['roa'] = float(net_income / total_assets * 100) if total_assets > 0 else 0
        ratios['roe'] = float(net_income / total_equity * 100) if total_equity > 0 else 0
        
        # Activity Ratios
        cost_of_goods_sold = Decimal(str(income_statement.get('cost_of_goods_sold', 0)))
        receivables = Decimal(str(balance_sheet.get('accounts_receivable', 0)))
        
        ratios['asset_turnover'] = float(revenue / total_assets) if total_assets > 0 else 0
        ratios['inventory_turnover'] = float(cost_of_goods_sold / inventory) if inventory > 0 else 0
        ratios['receivables_turnover'] = float(revenue / receivables) if receivables > 0 else 0
        
        # Coverage Ratios
        ebit = Decimal(str(income_statement.get('ebit', 0)))
        interest_expense = Decimal(str(income_statement.get('interest_expense', 0)))
        
        ratios['interest_coverage'] = float(ebit / interest_expense) if interest_expense > 0 else 0
        
        return ratios

# Generate sample tax data
def generate_uae_tax_data():
    tax_system = UAETaxSystem()
    
    # Sample transactions for VAT calculation
    transactions = []
    for month in range(1, 13):
        period = f"2024-{month:02d}"
        
        # Sales transactions
        sales_amount = random.uniform(50000, 150000)
        transactions.append({
            'period': period,
            'type': 'sales',
            'amount': sales_amount
        })
        
        # Expense transactions
        expense_amount = random.uniform(20000, 80000)
        transactions.append({
            'period': period,
            'type': 'expenses',
            'amount': expense_amount
        })
    
    # Generate VAT returns
    vat_returns = []
    for month in range(1, 13):
        period = f"2024-{month:02d}"
        vat_return = tax_system.generate_vat_return(transactions, period)
        vat_returns.append(vat_return)
    
    # Generate income tax return
    financial_data = {
        'total_revenue': 1200000,
        'total_expenses': 800000
    }
    
    income_tax_return = tax_system.generate_income_tax_return(financial_data, 2024)
    
    # Save to CSV files
    with open('uae_vat_returns.csv', 'w', newline='', encoding='utf-8') as file:
        writer = csv.DictWriter(file, fieldnames=vat_returns[0].keys())
        writer.writeheader()
        writer.writerows(vat_returns)
    
    with open('uae_income_tax_return.csv', 'w', newline='', encoding='utf-8') as file:
        writer = csv.DictWriter(file, fieldnames=income_tax_return.keys())
        writer.writeheader()
        writer.writerow(income_tax_return)
    
    return {
        'vat_returns': vat_returns,
        'income_tax_return': income_tax_return
    }

if __name__ == "__main__":
    result = generate_uae_tax_data()
    print("UAE Tax Data Generated Successfully!")
    print(f"VAT Returns: {len(result['vat_returns'])}")
    print(f"Income Tax Return: 1")