#!/usr/bin/env python3
"""
Generate sample financial data for the reporting application
This creates realistic financial data based on typical business scenarios
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import json
import csv

# Set random seed for reproducibility
np.random.seed(42)

# Generate Chart of Accounts
accounts = [
    # Assets
    {"account_id": "1000", "account_name": "Cash and Cash Equivalents", "account_type": "Assets", "account_category": "Current Assets"},
    {"account_id": "1100", "account_name": "Accounts Receivable", "account_type": "Assets", "account_category": "Current Assets"},
    {"account_id": "1200", "account_name": "Inventory", "account_type": "Assets", "account_category": "Current Assets"},
    {"account_id": "1500", "account_name": "Property, Plant & Equipment", "account_type": "Assets", "account_category": "Fixed Assets"},
    {"account_id": "1600", "account_name": "Accumulated Depreciation", "account_type": "Assets", "account_category": "Fixed Assets"},
    
    # Liabilities
    {"account_id": "2000", "account_name": "Accounts Payable", "account_type": "Liabilities", "account_category": "Current Liabilities"},
    {"account_id": "2100", "account_name": "Short-term Debt", "account_type": "Liabilities", "account_category": "Current Liabilities"},
    {"account_id": "2200", "account_name": "Long-term Debt", "account_type": "Liabilities", "account_category": "Long-term Liabilities"},
    
    # Equity
    {"account_id": "3000", "account_name": "Common Stock", "account_type": "Equity", "account_category": "Shareholders Equity"},
    {"account_id": "3100", "account_name": "Retained Earnings", "account_type": "Equity", "account_category": "Shareholders Equity"},
    
    # Revenue
    {"account_id": "4000", "account_name": "Sales Revenue", "account_type": "Revenue", "account_category": "Operating Revenue"},
    {"account_id": "4100", "account_name": "Service Revenue", "account_type": "Revenue", "account_category": "Operating Revenue"},
    
    # Expenses
    {"account_id": "5000", "account_name": "Cost of Goods Sold", "account_type": "Expenses", "account_category": "Direct Costs"},
    {"account_id": "5100", "account_name": "Salaries and Wages", "account_type": "Expenses", "account_category": "Operating Expenses"},
    {"account_id": "5200", "account_name": "Rent Expense", "account_type": "Expenses", "account_category": "Operating Expenses"},
    {"account_id": "5300", "account_name": "Utilities Expense", "account_type": "Expenses", "account_category": "Operating Expenses"},
    {"account_id": "5400", "account_name": "Marketing Expense", "account_type": "Expenses", "account_category": "Operating Expenses"},
    {"account_id": "5500", "account_name": "Depreciation Expense", "account_type": "Expenses", "account_category": "Operating Expenses"}
]

# Save accounts to CSV
accounts_df = pd.DataFrame(accounts)
accounts_df.to_csv('accounts.csv', index=False, encoding='utf-8')

# Generate monthly financial data for 2 years
start_date = datetime(2023, 1, 1)
end_date = datetime(2024, 12, 31)
date_range = pd.date_range(start=start_date, end=end_date, freq='M')

# Generate balance sheet data
balance_sheet_data = []
for date in date_range:
    # Cash (growing with some volatility)
    cash = 50000 + np.random.normal(2000, 1000) * (date.month + (date.year - 2023) * 12)
    
    # Accounts Receivable (15% of monthly revenue)
    monthly_revenue = 80000 + np.random.normal(0, 5000)
    ar = monthly_revenue * 0.15
    
    # Inventory (20% of monthly COGS)
    cogs = monthly_revenue * 0.6
    inventory = cogs * 0.2
    
    # Fixed Assets (depreciating)
    ppe = 200000 - (date.month + (date.year - 2023) * 12) * 2000
    
    # Liabilities
    ap = monthly_revenue * 0.1
    short_term_debt = 30000 - (date.month + (date.year - 2023) * 12) * 500
    long_term_debt = 100000 - (date.month + (date.year - 2023) * 12) * 1000
    
    # Equity
    retained_earnings = (monthly_revenue - cogs - 25000) * (date.month + (date.year - 2023) * 12)
    
    balance_sheet_data.extend([
        {"report_date": date, "account_id": "1000", "balance": max(cash, 10000), "period_type": "Monthly"},
        {"report_date": date, "account_id": "1100", "balance": max(ar, 5000), "period_type": "Monthly"},
        {"report_date": date, "account_id": "1200", "balance": max(inventory, 5000), "period_type": "Monthly"},
        {"report_date": date, "account_id": "1500", "balance": max(ppe, 50000), "period_type": "Monthly"},
        {"report_date": date, "account_id": "2000", "balance": max(ap, 2000), "period_type": "Monthly"},
        {"report_date": date, "account_id": "2100", "balance": max(short_term_debt, 5000), "period_type": "Monthly"},
        {"report_date": date, "account_id": "2200", "balance": max(long_term_debt, 20000), "period_type": "Monthly"},
        {"report_date": date, "account_id": "3100", "balance": max(retained_earnings, 10000), "period_type": "Monthly"}
    ])

# Save balance sheet data
balance_sheet_df = pd.DataFrame(balance_sheet_data)
balance_sheet_df.to_csv('balance_sheet.csv', index=False, encoding='utf-8')

# Generate income statement data
income_statement_data = []
for date in date_range:
    monthly_revenue = 80000 + np.random.normal(0, 5000)
    cogs = monthly_revenue * 0.6
    salaries = 15000 + np.random.normal(0, 500)
    rent = 3000
    utilities = 1000 + np.random.normal(0, 100)
    marketing = 2000 + np.random.normal(0, 200)
    depreciation = 2000
    
    income_statement_data.extend([
        {"report_date": date, "account_id": "4000", "amount": monthly_revenue, "period_type": "Monthly"},
        {"report_date": date, "account_id": "5000", "amount": cogs, "period_type": "Monthly"},
        {"report_date": date, "account_id": "5100", "amount": salaries, "period_type": "Monthly"},
        {"report_date": date, "account_id": "5200", "amount": rent, "period_type": "Monthly"},
        {"report_date": date, "account_id": "5300", "amount": utilities, "period_type": "Monthly"},
        {"report_date": date, "account_id": "5400", "amount": marketing, "period_type": "Monthly"},
        {"report_date": date, "account_id": "5500", "amount": depreciation, "period_type": "Monthly"}
    ])

# Save income statement data
income_statement_df = pd.DataFrame(income_statement_data)
income_statement_df.to_csv('income_statement.csv', index=False, encoding='utf-8')

# Generate cash flow data
cash_flow_data = []
for date in date_range:
    operating = 15000 + np.random.normal(0, 2000)
    investing = -3000 - np.random.normal(0, 1000)
    financing = -2000 - np.random.normal(0, 500)
    net_change = operating + investing + financing
    
    cash_flow_data.append({
        "report_date": date,
        "operating_activities": operating,
        "investing_activities": investing,
        "financing_activities": financing,
        "net_change": net_change,
        "period_type": "Monthly"
    })

# Save cash flow data
cash_flow_df = pd.DataFrame(cash_flow_data)
cash_flow_df.to_csv('cash_flow.csv', index=False, encoding='utf-8')

# Generate KPI data
kpi_data = []
for date in date_range:
    revenue = income_statement_df[income_statement_df['report_date'] == date]['amount'].sum()
    cogs = income_statement_df[(income_statement_df['report_date'] == date) & 
                               (income_statement_df['account_id'] == '5000')]['amount'].values[0]
    total_expenses = income_statement_df[(income_statement_df['report_date'] == date) & 
                                        (income_statement_df['account_id'] != '4000')]['amount'].sum()
    
    net_income = revenue - total_expenses
    
    # Get balance sheet items
    cash = balance_sheet_df[(balance_sheet_df['report_date'] == date) & 
                           (balance_sheet_df['account_id'] == '1000')]['balance'].values[0]
    ar = balance_sheet_df[(balance_sheet_df['report_date'] == date) & 
                         (balance_sheet_df['account_id'] == '1100')]['balance'].values[0]
    inventory = balance_sheet_df[(balance_sheet_df['report_date'] == date) & 
                                (balance_sheet_df['account_id'] == '1200')]['balance'].values[0]
    ppe = balance_sheet_df[(balance_sheet_df['report_date'] == date) & 
                          (balance_sheet_df['account_id'] == '1500')]['balance'].values[0]
    
    ap = balance_sheet_df[(balance_sheet_df['report_date'] == date) & 
                         (balance_sheet_df['account_id'] == '2000')]['balance'].values[0]
    short_debt = balance_sheet_df[(balance_sheet_df['report_date'] == date) & 
                                 (balance_sheet_df['account_id'] == '2100')]['balance'].values[0]
    long_debt = balance_sheet_df[(balance_sheet_df['report_date'] == date) & 
                                (balance_sheet_df['account_id'] == '2200')]['balance'].values[0]
    
    retained_earnings = balance_sheet_df[(balance_sheet_df['report_date'] == date) & 
                                        (balance_sheet_df['account_id'] == '3100')]['balance'].values[0]
    
    total_assets = cash + ar + inventory + ppe
    total_liabilities = ap + short_debt + long_debt
    equity = retained_earnings
    
    current_ratio = (cash + ar + inventory) / max(ap + short_debt, 1)
    debt_to_equity = total_liabilities / max(equity, 1)
    gross_margin = ((revenue - cogs) / max(revenue, 1)) * 100
    net_margin = (net_income / max(revenue, 1)) * 100
    roa = (net_income / max(total_assets, 1)) * 100
    roe = (net_income / max(equity, 1)) * 100
    
    kpi_data.append({
        "report_date": date,
        "revenue": revenue,
        "net_income": net_income,
        "total_assets": total_assets,
        "total_liabilities": total_liabilities,
        "equity": equity,
        "current_ratio": max(current_ratio, 0),
        "debt_to_equity": max(debt_to_equity, 0),
        "gross_margin": max(gross_margin, 0),
        "net_margin": max(net_margin, 0),
        "roa": max(roa, 0),
        "roe": max(roe, 0)
    })

# Save KPI data
kpi_df = pd.DataFrame(kpi_data)
kpi_df.to_csv('financial_kpis.csv', index=False, encoding='utf-8')

print("Financial data generation completed!")
print(f"Generated {len(accounts)} accounts")
print(f"Generated {len(balance_sheet_data)} balance sheet records")
print(f"Generated {len(income_statement_data)} income statement records")
print(f"Generated {len(cash_flow_data)} cash flow records")
print(f"Generated {len(kpi_data)} KPI records")