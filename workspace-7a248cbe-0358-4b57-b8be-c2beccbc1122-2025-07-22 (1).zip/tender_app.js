// Tender Management and Pricing System
// Includes: Tenders, Quantity Takeoffs, Pricing, Quotation Generation

// Global variables
let tenderData = {
    tenders: [],
    quantities: [],
    quotations: []
};

// Initialize tender system
document.addEventListener('DOMContentLoaded', function() {
    loadTenderData();
    loadQuantityData();
    updateTenderStats();
    renderTendersTable();
    renderQuantitiesTable();
    renderTenderChart();
    populateProjectDropdowns();
});

// Load tender data
function loadTenderData() {
    fetch('data/tenders.csv')
        .then(response => response.text())
        .then(csv => {
            tenderData.tenders = parseCSV(csv);
            updateTenderStats();
            renderTendersTable();
            renderTenderChart();
        })
        .catch(error => console.error('Error loading tenders:', error));
}

// Load quantity data
function loadQuantityData() {
    fetch('data/quantity_takeoffs.csv')
        .then(response => response.text())
        .then(csv => {
            tenderData.quantities = parseCSV(csv);
            renderQuantitiesTable();
        })
        .catch(error => console.error('Error loading quantities:', error));
}

// Update tender statistics
function updateTenderStats() {
    const totalTenders = tenderData.tenders.length;
    const activeTenders = tenderData.tenders.filter(t => t.status === 'Active').length;
    const wonTenders = tenderData.tenders.filter(t => t.status === 'Won').length;
    const totalValue = tenderData.tenders.reduce((sum, t) => sum + parseFloat(t.estimated_value || 0), 0);

    document.getElementById('total-tenders').textContent = totalTenders;
    document.getElementById('active-tenders').textContent = activeTenders;
    document.getElementById('won-tenders').textContent = wonTenders;
    document.getElementById('total-value').textContent = formatCurrency(totalValue);
}

// Render tenders table
function renderTendersTable() {
    const tbody = document.getElementById('tenders-tbody');
    if (!tbody) return;

    tbody.innerHTML = '';
    
    tenderData.tenders.forEach(tender => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${tender.tender_number}</td>
            <td>${tender.project_name}</td>
            <td>${tender.client_name}</td>
            <td>${formatCurrency(parseFloat(tender.estimated_value || 0))}</td>
            <td>${formatDate(tender.deadline)}</td>
            <td><span class="badge ${getStatusBadgeClass(tender.status)}">${tender.status}</span></td>
            <td>
                <button class="btn btn-sm btn-outline-primary" onclick="editTender('${tender.tender_number}')">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-sm btn-outline-success" onclick="generateQuotation('${tender.tender_number}')">
                    <i class="fas fa-file-invoice"></i>
                </button>
                <button class="btn btn-sm btn-outline-danger" onclick="deleteTender('${tender.tender_number}')">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

// Render quantities table
function renderQuantitiesTable() {
    const tbody = document.getElementById('quantities-tbody');
    if (!tbody) return;

    tbody.innerHTML = '';
    let total = 0;

    tenderData.quantities.forEach(item => {
        const subtotal = parseFloat(item.quantity || 0) * parseFloat(item.unit_price || 0);
        total += subtotal;

        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${item.item_name}</td>
            <td>${item.quantity} ${item.unit}</td>
            <td>${formatCurrency(parseFloat(item.unit_price || 0))}</td>
            <td>${formatCurrency(subtotal)}</td>
            <td>
                <button class="btn btn-sm btn-outline-danger" onclick="deleteQuantity(${item.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });

    document.getElementById('total-amount').textContent = formatCurrency(total);
}

// Render tender status chart
function renderTenderChart() {
    const ctx = document.getElementById('tenderStatusChart');
    if (!ctx) return;

    const statusCounts = {
        'Active': 0,
        'Submitted': 0,
        'Won': 0,
        'Lost': 0
    };

    tenderData.tenders.forEach(tender => {
        if (statusCounts.hasOwnProperty(tender.status)) {
            statusCounts[tender.status]++;
        }
    });

    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['نشطة', 'تم التقديم', 'فازت', 'خسرت'],
            datasets: [{
                data: [statusCounts.Active, statusCounts.Submitted, statusCounts.Won, statusCounts.Lost],
                backgroundColor: ['#3498db', '#f39c12', '#2ecc71', '#e74c3c']
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

// Populate project dropdowns
function populateProjectDropdowns() {
    const projectSelects = document.querySelectorAll('[id$="-project"]');
    
    projectSelects.forEach(select => {
        select.innerHTML = '<option value="">اختر المشروع</option>';
        
        tenderData.tenders.forEach(tender => {
            const option = document.createElement('option');
            option.value = tender.tender_number;
            option.textContent = tender.project_name;
            select.appendChild(option);
        });
    });
}

// Save tender
function saveTender() {
    const form = document.getElementById('add-tender-form');
    const formData = new FormData(form);
    
    const tender = {
        tender_number: formData.get('tender_number'),
        project_name: formData.get('project_name'),
        client_name: formData.get('client_name'),
        estimated_value: formData.get('estimated_value'),
        deadline: formData.get('deadline'),
        status: formData.get('status'),
        notes: formData.get('notes')
    };

    // Add to data
    tenderData.tenders.push(tender);
    
    // Update display
    updateTenderStats();
    renderTendersTable();
    renderTenderChart();
    
    // Close modal
    const modal = bootstrap.Modal.getInstance(document.getElementById('addTenderModal'));
    modal.hide();
    
    // Reset form
    form.reset();
    
    // Save to file (in real implementation)
    saveTenderData();
}

// Generate quotation
function generateQuotation(tenderNumber) {
    const tender = tenderData.tenders.find(t => t.tender_number === tenderNumber);
    if (!tender) return;

    const quantities = tenderData.quantities.filter(q => q.project_id === tenderNumber);
    
    const quotation = {
        quotation_number: `Q-${Date.now()}`,
        tender_number: tenderNumber,
        project_name: tender.project_name,
        client_name: tender.client_name,
        date: new Date().toISOString().split('T')[0],
        items: quantities,
        total: quantities.reduce((sum, item) => sum + (item.quantity * item.unit_price), 0),
        vat: 0,
        grand_total: 0
    };

    quotation.vat = quotation.total * 0.05; // 5% VAT UAE
    quotation.grand_total = quotation.total + quotation.vat;

    // Generate PDF
    generateQuotationPDF(quotation);
}

// Generate quotation PDF
function generateQuotationPDF(quotation) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    // Header
    doc.setFontSize(20);
    doc.text('عرض سعر', 105, 20, { align: 'center' });
    
    // Company info
    doc.setFontSize(12);
    doc.text('شركة المقاولات المتقدمة', 105, 30, { align: 'center' });
    doc.text('الإمارات العربية المتحدة', 105, 37, { align: 'center' });

    // Quotation details
    doc.setFontSize(10);
    doc.text(`رقم العرض: ${quotation.quotation_number}`, 20, 50);
    doc.text(`التاريخ: ${quotation.date}`, 20, 57);
    doc.text(`المشروع: ${quotation.project_name}`, 20, 64);
    doc.text(`العميل: ${quotation.client_name}`, 20, 71);

    // Items table
    let yPos = 90;
    doc.setFontSize(12);
    doc.text('تفاصيل الأصناف:', 20, yPos);
    yPos += 10;

    // Table headers
    doc.setFontSize(10);
    doc.text('البند', 20, yPos);
    doc.text('الكمية', 80, yPos);
    doc.text('السعر', 110, yPos);
    doc.text('الإجمالي', 140, yPos);
    yPos += 7;

    // Items
    quotation.items.forEach(item => {
        doc.text(item.item_name, 20, yPos);
        doc.text(`${item.quantity} ${item.unit}`, 80, yPos);
        doc.text(formatCurrency(item.unit_price), 110, yPos);
        doc.text(formatCurrency(item.quantity * item.unit_price), 140, yPos);
        yPos += 7;
    });

    // Totals
    yPos += 10;
    doc.text(`الإجمالي: ${formatCurrency(quotation.total)}`, 140, yPos);
    yPos += 7;
    doc.text(`ضريبة القيمة المضافة (5%): ${formatCurrency(quotation.vat)}`, 140, yPos);
    yPos += 7;
    doc.setFontSize(12);
    doc.text(`الإجمالي النهائي: ${formatCurrency(quotation.grand_total)}`, 140, yPos);

    // Terms and conditions
    yPos += 20;
    doc.setFontSize(10);
    doc.text('الشروط والأحكام:', 20, yPos);
    yPos += 7;
    doc.text('- مدة سريان العرض: 30 يوم', 20, yPos);
    yPos += 5;
    doc.text('- الدفع: 30% مقدم، 70% عند الإنجاز', 20, yPos);
    yPos += 5;
    doc.text('- فترة التنفيذ: حسب الاتفاق', 20, yPos);

    // Save PDF
    doc.save(`عرض-سعر-${quotation.quotation_number}.pdf`);
}

// Quantity form handler
document.getElementById('quantity-form')?.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    const quantity = {
        id: Date.now(),
        project_id: formData.get('project'),
        item_name: formData.get('item'),
        unit: formData.get('unit'),
        quantity: parseFloat(formData.get('amount')),
        unit_price: parseFloat(formData.get('unit-price'))
    };

    tenderData.quantities.push(quantity);
    renderQuantitiesTable();
    this.reset();
    saveQuantityData();
});

// Utility functions
function formatCurrency(amount) {
    return new Intl.NumberFormat('ar-AE', {
        style: 'currency',
        currency: 'AED'
    }).format(amount);
}

function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('ar-AE');
}

function getStatusBadgeClass(status) {
    const classes = {
        'Active': 'bg-primary',
        'Submitted': 'bg-warning',
        'Won': 'bg-success',
        'Lost': 'bg-danger'
    };
    return classes[status] || 'bg-secondary';
}

function parseCSV(csv) {
    const lines = csv.trim().split('\n');
    const headers = lines[0].split(',');
    return lines.slice(1).map(line => {
        const values = line.split(',');
        const obj = {};
        headers.forEach((header, index) => {
            obj[header.trim()] = values[index]?.trim() || '';
        });
        return obj;
    });
}

// Save data functions
function saveTenderData() {
    // In real implementation, save to server
    console.log('Saving tender data...');
}

function saveQuantityData() {
    // In real implementation, save to server
    console.log('Saving quantity data...');
}

// Export functions
function exportTenderReport() {
    const csv = convertToCSV(tenderData.tenders);
    downloadCSV(csv, 'tenders-report.csv');
}

function convertToCSV(data) {
    if (!data.length) return '';
    
    const headers = Object.keys(data[0]);
    const csvHeaders = headers.join(',');
    const csvRows = data.map(row => 
        headers.map(header => `"${row[header] || ''}"`).join(',')
    );
    
    return [csvHeaders, ...csvRows].join('\n');
}

function downloadCSV(csv, filename) {
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    link.click();
}

// Notification system
function sendNotification() {
    // In real implementation, send email/SMS
    alert('سيتم إرسال الإشعار قريباً');
}