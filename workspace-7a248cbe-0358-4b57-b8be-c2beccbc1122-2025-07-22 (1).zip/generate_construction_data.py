#!/usr/bin/env python3
"""
Generate sample construction project data
"""

import csv
import json
import random
from datetime import datetime, timedelta

# Set random seed for reproducible data
random.seed(42)

# Helper functions
def random_date(start_date, end_date):
    """Generate random date between two dates"""
    delta = end_date - start_date
    random_days = random.randint(0, delta.days)
    return start_date + timedelta(days=random_days)

def generate_project_id():
    """Generate project ID"""
    return f"PROJ-{random.randint(1000, 9999)}"

def generate_tender_id():
    """Generate tender ID"""
    return f"TEN-{random.randint(1000, 9999)}"

def generate_contract_id():
    """Generate contract ID"""
    return f"CON-{random.randint(1000, 9999)}"

def generate_supplier_id():
    """Generate supplier ID"""
    return f"SUP-{random.randint(1000, 9999)}"

# Generate projects
def generate_projects():
    projects = []
    project_types = ['residential', 'commercial', 'industrial', 'infrastructure', 'government']
    statuses = ['planning', 'active', 'on_hold', 'completed', 'cancelled']
    
    clients = [
        'شركة الإمارات للتطوير العقاري',
        'بلدية دبي',
        'وزارة الأشغال العامة',
        'شركة أبوظبي الوطنية',
        'مجموعة الاتحاد العقارية',
        'شركة دبي للاستثمار',
        'بلدية أبوظبي',
        'شركة الشارقة للتطوير'
    ]
    
    locations = [
        'دبي - منطقة البرشاء',
        'أبوظبي - جزيرة ياس',
        'الشارقة - المنطقة الحرة',
        'عجمان - المنطقة الصناعية',
        'رأس الخيمة - المنطقة الجديدة',
        'الفجيرة - المنطقة السكنية',
        'أم القيوين - المنطقة التجارية'
    ]
    
    managers = [
        'أحمد محمد',
        'خالد عبدالله',
        'محمد علي',
        'سعيد حسن',
        'يوسف أحمد',
        'عمر خالد',
        'فهد سعيد'
    ]
    
    for i in range(15):
        start_date = random_date(datetime(2023, 1, 1), datetime(2024, 6, 1))
        duration = random.randint(180, 730)  # 6 months to 2 years
        expected_end = start_date + timedelta(days=duration)
        
        project = {
            'project_id': generate_project_id(),
            'project_name': f"مشروع {random.choice(['سكني', 'تجاري', 'صناعي', 'بنية تحتية'])} {i+1}",
            'project_type': random.choice(project_types),
            'client_name': random.choice(clients),
            'client_contact': f"05{random.randint(10000000, 99999999)}",
            'client_email': f"client{i+1}@company.ae",
            'project_location': random.choice(locations),
            'contract_value': round(random.uniform(500000, 50000000), 2),
            'start_date': start_date.strftime('%Y-%m-%d'),
            'expected_end_date': expected_end.strftime('%Y-%m-%d'),
            'actual_end_date': '',
            'project_status': random.choice(statuses),
            'project_manager': random.choice(managers),
            'description': f"وصف المشروع {i+1}"
        }
        projects.append(project)
    
    return projects

# Generate tenders
def generate_tenders(projects):
    tenders = []
    tender_types = ['public', 'private', 'invited']
    statuses = ['draft', 'submitted', 'awarded', 'rejected', 'cancelled']
    
    for project in projects:
        if random.random() < 0.8:  # 80% of projects have tenders
            submission_date = datetime.strptime(project['start_date'], '%Y-%m-%d') - timedelta(days=random.randint(30, 90))
            
            tender = {
                'tender_id': generate_tender_id(),
                'project_id': project['project_id'],
                'tender_name': f"مناقصة {project['project_name']}",
                'tender_type': random.choice(tender_types),
                'submission_deadline': submission_date.strftime('%Y-%m-%d'),
                'opening_date': (submission_date + timedelta(days=7)).strftime('%Y-%m-%d'),
                'estimated_value': project['contract_value'] * random.uniform(0.9, 1.1),
                'tender_status': random.choice(statuses),
                'bid_amount': project['contract_value'] * random.uniform(0.85, 0.98),
                'bid_submission_date': (submission_date - timedelta(days=random.randint(1, 10))).strftime('%Y-%m-%d'),
                'bid_result_date': (submission_date + timedelta(days=14)).strftime('%Y-%m-%d'),
                'notes': f"ملاحظات المناقصة {project['project_id']}"
            }
            tenders.append(tender)
    
    return tenders

# Generate quantity takeoff
def generate_quantity_takeoff(projects):
    takeoffs = []
    categories = ['خرسانة', 'حديد', 'طوب', 'كهرباء', 'سباكة', 'نجارة', 'دهان', 'بلاط']
    units = ['م3', 'طن', 'م2', 'نقطة', 'متر', 'قطعة', 'كجم', 'لتر']
    
    for project in projects:
        num_items = random.randint(10, 25)
        for j in range(num_items):
            quantity = random.uniform(10, 1000)
            unit_price = random.uniform(50, 5000)
            
            takeoff = {
                'takeoff_id': len(takeoffs) + 1,
                'project_id': project['project_id'],
                'item_code': f"ITEM-{random.randint(1000, 9999)}",
                'item_description': f"{random.choice(categories)} - بند {j+1}",
                'unit': random.choice(units),
                'quantity': round(quantity, 3),
                'unit_price': round(unit_price, 2),
                'total_price': round(quantity * unit_price, 2),
                'category': random.choice(categories),
                'subcategory': f"نوع {random.randint(1, 5)}",
                'specifications': f"مواصفات البند {j+1}"
            }
            takeoffs.append(takeoff)
    
    return takeoffs

# Generate contracts
def generate_contracts(projects):
    contracts = []
    statuses = ['draft', 'signed', 'active', 'completed', 'terminated']
    
    for project in projects:
        if random.random() < 0.9:  # 90% of projects have contracts
            contract = {
                'contract_id': generate_contract_id(),
                'project_id': project['project_id'],
                'contract_number': f"CON-{project['project_id']}",
                'contract_date': (datetime.strptime(project['start_date'], '%Y-%m-%d') - timedelta(days=random.randint(1, 30))).strftime('%Y-%m-%d'),
                'contract_value': project['contract_value'],
                'advance_payment': project['contract_value'] * random.uniform(0.1, 0.2),
                'retention_percentage': random.uniform(5, 10),
                'performance_bond': project['contract_value'] * random.uniform(0.05, 0.1),
                'contract_duration': random.randint(180, 730),
                'penalty_clause': 'غرامة 0.1% من قيمة العقد لكل يوم تأخير',
                'payment_terms': 'دفعات شهرية حسب نسبة الإنجاز',
                'contract_status': random.choice(statuses)
            }
            contracts.append(contract)
    
    return contracts

# Generate suppliers
def generate_suppliers():
    suppliers = []
    supplier_names = [
        'شركة الإمارات للمواد البناء',
        'مؤسسة الخليج للمقاولات',
        'شركة دبي للخرسانة الجاهزة',
        'مؤسسة أبوظبي للحديد',
        'شركة الشارقة للكهرباء',
        'مؤسسة عجمان للسباكة',
        'شركة رأس الخيمة للنجارة',
        'مؤسسة الفجيرة للدهانات'
    ]
    
    types = ['materials', 'equipment', 'subcontractor', 'services']
    
    for i, name in enumerate(supplier_names):
        supplier = {
            'supplier_id': generate_supplier_id(),
            'supplier_name': name,
            'contact_person': f"مدير {i+1}",
            'phone': f"05{random.randint(10000000, 99999999)}",
            'email': f"supplier{i+1}@company.ae",
            'address': f"عنوان المورد {i+1}",
            'supplier_type': random.choice(types),
            'credit_limit': random.uniform(100000, 1000000),
            'payment_terms': f"{random.randint(30, 90)} يوم",
            'status': 'active'
        }
        suppliers.append(supplier)
    
    return suppliers

# Generate project costs
def generate_project_costs(projects, suppliers):
    costs = []
    categories = ['materials', 'labor', 'equipment', 'subcontractor', 'overhead', 'other']
    types = ['direct', 'indirect']
    statuses = ['pending', 'paid', 'partial']
    
    for project in projects:
        num_costs = random.randint(5, 20)
        for j in range(num_costs):
            supplier = random.choice(suppliers)
            cost = {
                'cost_id': len(costs) + 1,
                'project_id': project['project_id'],
                'cost_category': random.choice(categories),
                'cost_type': random.choice(types),
                'description': f"تكلفة {random.choice(categories)} - {j+1}",
                'amount': round(random.uniform(1000, 50000), 2),
                'cost_date': random_date(
                    datetime.strptime(project['start_date'], '%Y-%m-%d'),
                    datetime.strptime(project['expected_end_date'], '%Y-%m-%d')
                ).strftime('%Y-%m-%d'),
                'vendor_name': supplier['supplier_name'],
                'invoice_number': f"INV-{random.randint(10000, 99999)}",
                'payment_status': random.choice(statuses),
                'notes': f"ملاحظات التكلفة {j+1}"
            }
            costs.append(cost)
    
    return costs

# Generate work progress
def generate_work_progress(projects):
    progress_records = []
    
    for project in projects:
        if project['project_status'] in ['active', 'completed']:
            num_records = random.randint(3, 8)
            for j in range(num_records):
                planned_quantity = random.uniform(100, 1000)
                actual_quantity = planned_quantity * random.uniform(0.7, 1.1)
                planned_cost = random.uniform(50000, 200000)
                actual_cost = planned_cost * random.uniform(0.8, 1.2)
                
                progress = {
                    'progress_id': len(progress_records) + 1,
                    'project_id': project['project_id'],
                    'work_item': f"بند العمل {j+1}",
                    'planned_quantity': round(planned_quantity, 2),
                    'actual_quantity': round(actual_quantity, 2),
                    'planned_cost': round(planned_cost, 2),
                    'actual_cost': round(actual_cost, 2),
                    'completion_percentage': round(random.uniform(20, 100), 2),
                    'progress_date': random_date(
                        datetime.strptime(project['start_date'], '%Y-%m-%d'),
                        datetime.strptime(project['expected_end_date'], '%Y-%m-%d')
                    ).strftime('%Y-%m-%d'),
                    'notes': f"تقرير التقدم {j+1}"
                }
                progress_records.append(progress)
    
    return progress_records

# Generate client payments
def generate_client_payments(projects):
    payments = []
    types = ['advance', 'milestone', 'final', 'retention']
    statuses = ['pending', 'received', 'partial']
    
    for project in projects:
        num_payments = random.randint(2, 6)
        for j in range(num_payments):
            payment = {
                'payment_id': len(payments) + 1,
                'project_id': project['project_id'],
                'payment_date': random_date(
                    datetime.strptime(project['start_date'], '%Y-%m-%d'),
                    datetime.strptime(project['expected_end_date'], '%Y-%m-%d')
                ).strftime('%Y-%m-%d'),
                'payment_amount': round(project['contract_value'] / num_payments, 2),
                'payment_type': random.choice(types),
                'invoice_number': f"INV-{random.randint(10000, 99999)}",
                'payment_status': random.choice(statuses),
                'notes': f"دفعة العميل {j+1}"
            }
            payments.append(payment)
    
    return payments

# Generate supplier payments
def generate_supplier_payments(projects, suppliers):
    payments = []
    methods = ['cash', 'cheque', 'bank_transfer', 'credit']
    
    for project in projects:
        num_payments = random.randint(3, 10)
        for j in range(num_payments):
            supplier = random.choice(suppliers)
            invoice_amount = random.uniform(5000, 50000)
            paid_amount = invoice_amount * random.uniform(0.5, 1.0)
            
            payment = {
                'payment_id': len(payments) + 1,
                'project_id': project['project_id'],
                'supplier_id': supplier['supplier_id'],
                'invoice_number': f"SUP-{random.randint(10000, 99999)}",
                'invoice_amount': round(invoice_amount, 2),
                'paid_amount': round(paid_amount, 2),
                'payment_date': random_date(
                    datetime(2023, 1, 1),
                    datetime(2024, 12, 31)
                ).strftime('%Y-%m-%d'),
                'payment_method': random.choice(methods),
                'notes': f"دفعة المورد {j+1}"
            }
            payments.append(payment)
    
    return payments

# Generate project milestones
def generate_project_milestones(projects):
    milestones = []
    
    for project in projects:
        num_milestones = random.randint(3, 8)
        for j in range(num_milestones):
            milestone = {
                'milestone_id': len(milestones) + 1,
                'project_id': project['project_id'],
                'milestone_name': f"مرحلة {j+1} - {project['project_name']}",
                'planned_date': random_date(
                    datetime.strptime(project['start_date'], '%Y-%m-%d'),
                    datetime.strptime(project['expected_end_date'], '%Y-%m-%d')
                ).strftime('%Y-%m-%d'),
                'actual_date': '',
                'completion_status': random.choice(['pending', 'completed', 'delayed']),
                'payment_percentage': round(100 / num_milestones, 2),
                'payment_amount': round(project['contract_value'] / num_milestones, 2),
                'notes': f"ملاحظات المرحلة {j+1}"
            }
            milestones.append(milestone)
    
    return milestones

# Main function to generate all data
def generate_all_construction_data():
    print("Generating construction project data...")
    
    # Generate all data
    projects = generate_projects()
    tenders = generate_tenders(projects)
    takeoffs = generate_quantity_takeoff(projects)
    contracts = generate_contracts(projects)
    suppliers = generate_suppliers()
    costs = generate_project_costs(projects, suppliers)
    progress = generate_work_progress(projects)
    client_payments = generate_client_payments(projects)
    supplier_payments = generate_supplier_payments(projects, suppliers)
    milestones = generate_project_milestones(projects)
    
    # Save to CSV files
    def save_to_csv(data, filename, fieldnames):
        with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(data)
    
    # Save projects
    save_to_csv(projects, 'construction_projects.csv', [
        'project_id', 'project_name', 'project_type', 'client_name', 'client_contact',
        'client_email', 'project_location', 'contract_value', 'start_date',
        'expected_end_date', 'actual_end_date', 'project_status', 'project_manager',
        'description'
    ])
    
    # Save tenders
    save_to_csv(tenders, 'construction_tenders.csv', [
        'tender_id', 'project_id', 'tender_name', 'tender_type', 'submission_deadline',
        'opening_date', 'estimated_value', 'tender_status', 'bid_amount',
        'bid_submission_date', 'bid_result_date', 'notes'
    ])
    
    # Save quantity takeoff
    save_to_csv(takeoffs, 'construction_quantity_takeoff.csv', [
        'takeoff_id', 'project_id', 'item_code', 'item_description', 'unit',
        'quantity', 'unit_price', 'total_price', 'category', 'subcategory',
        'specifications'
    ])
    
    # Save contracts
    save_to_csv(contracts, 'construction_contracts.csv', [
        'contract_id', 'project_id', 'contract_number', 'contract_date',
        'contract_value', 'advance_payment', 'retention_percentage',
        'performance_bond', 'contract_duration', 'penalty_clause',
        'payment_terms', 'contract_status'
    ])
    
    # Save suppliers
    save_to_csv(suppliers, 'construction_suppliers.csv', [
        'supplier_id', 'supplier_name', 'contact_person', 'phone', 'email',
        'address', 'supplier_type', 'credit_limit', 'payment_terms', 'status'
    ])
    
    # Save project costs
    save_to_csv(costs, 'construction_project_costs.csv', [
        'cost_id', 'project_id', 'cost_category', 'cost_type', 'description',
        'amount', 'cost_date', 'vendor_name', 'invoice_number', 'payment_status',
        'notes'
    ])
    
    # Save work progress
    save_to_csv(progress, 'construction_work_progress.csv', [
        'progress_id', 'project_id', 'work_item', 'planned_quantity',
        'actual_quantity', 'planned_cost', 'actual_cost', 'completion_percentage',
        'progress_date', 'notes'
    ])
    
    # Save client payments
    save_to_csv(client_payments, 'construction_client_payments.csv', [
        'payment_id', 'project_id', 'payment_date', 'payment_amount',
        'payment_type', 'invoice_number', 'payment_status', 'notes'
    ])
    
    # Save supplier payments
    save_to_csv(supplier_payments, 'construction_supplier_payments.csv', [
        'payment_id', 'project_id', 'supplier_id', 'invoice_number',
        'invoice_amount', 'paid_amount', 'payment_date', 'payment_method',
        'notes'
    ])
    
    # Save milestones
    save_to_csv(milestones, 'construction_project_milestones.csv', [
        'milestone_id', 'project_id', 'milestone_name', 'planned_date',
        'actual_date', 'completion_status', 'payment_percentage',
        'payment_amount', 'notes'
    ])
    
    # Save summary to JSON
    summary = {
        'projects': len(projects),
        'tenders': len(tenders),
        'takeoffs': len(takeoffs),
        'contracts': len(contracts),
        'suppliers': len(suppliers),
        'costs': len(costs),
        'progress_records': len(progress),
        'client_payments': len(client_payments),
        'supplier_payments': len(supplier_payments),
        'milestones': len(milestones)
    }
    
    with open('construction_data_summary.json', 'w', encoding='utf-8') as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    
    print("Construction data generation completed!")
    print(f"Generated {len(projects)} projects")
    print(f"Generated {len(tenders)} tenders")
    print(f"Generated {len(takeoffs)} quantity takeoffs")
    print(f"Generated {len(contracts)} contracts")
    print(f"Generated {len(suppliers)} suppliers")
    print(f"Generated {len(costs)} project costs")
    print(f"Generated {len(progress)} progress records")
    print(f"Generated {len(client_payments)} client payments")
    print(f"Generated {len(supplier_payments)} supplier payments")
    print(f"Generated {len(milestones)} milestones")

if __name__ == "__main__":
    generate_all_construction_data()