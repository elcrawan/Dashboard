// AI-Powered Insights System
// Advanced analytics with machine learning predictions

class AIInsightsSystem {
    constructor() {
        this.models = new Map();
        this.insights = [];
        this.predictions = [];
        this.alerts = [];
    }

    // Initialize AI models
    async initializeModels() {
        this.models.set('budget_prediction', new BudgetPredictionModel());
        this.models.set('risk_assessment', new RiskAssessmentModel());
        this.models.set('profit_forecast', new ProfitForecastModel());
        this.models.set('timeline_prediction', new TimelinePredictionModel());
    }

    // Generate comprehensive insights
    async generateInsights(data) {
        const insights = [];

        // Financial insights
        insights.push(...await this.generateFinancialInsights(data));
        
        // Project insights
        insights.push(...await this.generateProjectInsights(data));
        
        // Risk insights
        insights.push(...await this.generateRiskInsights(data));
        
        // Performance insights
        insights.push(...await this.generatePerformanceInsights(data));

        this.insights = insights;
        return insights;
    }

    async generateFinancialInsights(data) {
        const insights = [];
        
        // Cash flow analysis
        const cashFlow = this.analyzeCashFlow(data.cashFlow);
        if (cashFlow.trend === 'declining') {
            insights.push({
                type: 'warning',
                title: 'انخفاض في التدفق النقدي',
                description: 'يوجد انخفاض في التدفق النقدي بنسبة ' + cashFlow.declineRate + '%',
                action: 'مراجعة المصروفات وزيادة التحصيل',
                priority: 'high',
                score: cashFlow.riskScore
            });
        }

        // Budget variance analysis
        const budgetVariance = this.analyzeBudgetVariance(data.projects);
        if (budgetVariance.overBudgetProjects.length > 0) {
            insights.push({
                type: 'danger',
                title: 'مشاريع تجاوزت الميزانية',
                description: `${budgetVariance.overBudgetProjects.length} مشروع تجاوز الميزانية`,
                action: 'مراجعة التكاليف واتخاذ إجراءات تصحيحية',
                priority: 'critical',
                projects: budgetVariance.overBudgetProjects
            });
        }

        // Profitability analysis
        const profitability = this.analyzeProfitability(data.incomeStatement);
        insights.push({
            type: 'info',
            title: 'تحليل الربحية',
            description: `متوسط هامش الربح: ${profitability.averageMargin}%`,
            trend: profitability.trend,
            forecast: profitability.forecast
        });

        return insights;
    }

    async generateProjectInsights(data) {
        const insights = [];
        
        // Timeline analysis
        const timeline = this.analyzeTimeline(data.projects);
        if (timeline.delayedProjects.length > 0) {
            insights.push({
                type: 'warning',
                title: 'تأخير في الجدول الزمني',
                description: `${timeline.delayedProjects.length} مشروع متأخر عن الجدول`,
                action: 'تحليل أسباب التأخير وتحديث الجدول الزمني',
                priority: 'medium',
                projects: timeline.delayedProjects
            });
        }

        // Resource utilization
        const resources = this.analyzeResourceUtilization(data.projects);
        if (resources.underutilized > 0) {
            insights.push({
                type: 'info',
                title: 'استغلال الموارد',
                description: `نسبة استغلال الموارد: ${resources.utilizationRate}%`,
                action: 'إعادة توزيع الموارد لتحسين الكفاءة',
                recommendations: resources.recommendations
            });
        }

        return insights;
    }

    async generateRiskInsights(data) {
        const insights = [];
        
        // Financial risk assessment
        const financialRisk = this.assessFinancialRisk(data);
        if (financialRisk.score > 70) {
            insights.push({
                type: 'danger',
                title: 'مخاطر مالية مرتفعة',
                description: `درجة المخاطر: ${financialRisk.score}/100`,
                factors: financialRisk.factors,
                mitigation: financialRisk.mitigation
            });
        }

        // Project risk analysis
        const projectRisk = this.assessProjectRisk(data.projects);
        projectRisk.forEach(risk => {
            insights.push({
                type: risk.level === 'high' ? 'danger' : 'warning',
                title: `مخاطر في مشروع ${risk.projectName}`,
                description: risk.description,
                probability: risk.probability,
                impact: risk.impact,
                mitigation: risk.mitigation
            });
        });

        return insights;
    }

    async generatePerformanceInsights(data) {
        const insights = [];
        
        // Overall performance metrics
        const performance = this.calculatePerformanceMetrics(data);
        insights.push({
            type: 'success',
            title: 'أداء عام',
            description: `مؤشر الأداء العام: ${performance.overallScore}/100`,
            kpis: performance.kpis,
            trends: performance.trends
        });

        // Benchmark comparison
        const benchmark = this.compareWithBenchmark(data);
        if (benchmark.belowAverage.length > 0) {
            insights.push({
                type: 'warning',
                title: 'أداء أقل من المتوسط',
                description: `${benchmark.belowAverage.length} مؤشر أداء أقل من المتوسط الصناعي`,
                areas: benchmark.belowAverage,
                recommendations: benchmark.recommendations
            });
        }

        return insights;
    }

    // Prediction models
    async generatePredictions(data) {
        const predictions = [];

        // Budget prediction
        const budgetPrediction = await this.predictBudget(data);
        predictions.push({
            type: 'budget',
            title: 'توقع الميزانية',
            current: budgetPrediction.current,
            predicted: budgetPrediction.predicted,
            confidence: budgetPrediction.confidence,
            factors: budgetPrediction.factors
        });

        // Timeline prediction
        const timelinePrediction = await this.predictTimeline(data);
        predictions.push({
            type: 'timeline',
            title: 'توقع الجدول الزمني',
            original: timelinePrediction.original,
            predicted: timelinePrediction.predicted,
            delay: timelinePrediction.predictedDelay,
            confidence: timelinePrediction.confidence
        });

        // Revenue prediction
        const revenuePrediction = await this.predictRevenue(data);
        predictions.push({
            type: 'revenue',
            title: 'توقع الإيرادات',
            current: revenuePrediction.current,
            predicted: revenuePrediction.predicted,
            growth: revenuePrediction.growthRate,
            confidence: revenuePrediction.confidence
        });

        this.predictions = predictions;
        return predictions;
    }

    // Advanced analytics
    analyzeCashFlow(cashFlow) {
        const recent = cashFlow.slice(-6);
        const older = cashFlow.slice(-12, -6);
        
        const recentAvg = recent.reduce((sum, item) => sum + item.amount, 0) / recent.length;
        const olderAvg = older.reduce((sum, item) => sum + item.amount, 0) / older.length;
        
        const declineRate = ((olderAvg - recentAvg) / olderAvg) * 100;
        const riskScore = Math.min(100, declineRate * 2);
        
        return {
            trend: declineRate > 10 ? 'declining' : declineRate < -10 ? 'improving' : 'stable',
            declineRate: Math.abs(declineRate).toFixed(1),
            riskScore: Math.round(riskScore)
        };
    }

    analyzeBudgetVariance(projects) {
        const overBudgetProjects = projects.filter(p => 
            p.actualCost > p.budget * 1.1
        );
        
        return {
            overBudgetProjects: overBudgetProjects,
            totalVariance: overBudgetProjects.reduce((sum, p) => 
                sum + (p.actualCost - p.budget), 0
            )
        };
    }

    analyzeProfitability(incomeStatement) {
        const margins = incomeStatement.map(item => 
            ((item.revenue - item.cost) / item.revenue) * 100
        );
        
        const avgMargin = margins.reduce((sum, m) => sum + m, 0) / margins.length;
        const trend = this.calculateTrend(margins);
        
        return {
            averageMargin: avgMargin.toFixed(1),
            trend: trend,
            forecast: this.forecastNextValue(margins)
        };
    }

    calculateTrend(values) {
        if (values.length < 2) return 'stable';
        
        const recent = values.slice(-3);
        const older = values.slice(-6, -3);
        
        const recentAvg = recent.reduce((a, b) => a + b, 0) / recent.length;
        const olderAvg = older.reduce((a, b) => a + b, 0) / older.length;
        
        const change = ((recentAvg - olderAvg) / olderAvg) * 100;
        
        if (change > 5) return 'improving';
        if (change < -5) return 'declining';
        return 'stable';
    }

    forecastNextValue(values) {
        if (values.length < 3) return values[values.length - 1];
        
        // Simple linear regression
        const n = values.length;
        const sumX = (n * (n - 1)) / 2;
        const sumY = values.reduce((a, b) => a + b, 0);
        const sumXY = values.reduce((sum, y, x) => sum + x * y, 0);
        const sumXX = values.reduce((sum, _, x) => sum + x * x, 0);
        
        const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
        const intercept = (sumY - slope * sumX) / n;
        
        return intercept + slope * n;
    }

    // Alert system
    generateAlerts(insights) {
        const alerts = [];
        
        insights.forEach(insight => {
            if (insight.priority === 'critical' || insight.priority === 'high') {
                alerts.push({
                    id: Date.now() + Math.random(),
                    type: insight.type,
                    title: insight.title,
                    message: insight.description,
                    priority: insight.priority,
                    timestamp: new Date().toISOString(),
                    read: false,
                    action: insight.action
                });
            }
        });

        this.alerts = alerts;
        this.displayAlerts(alerts);
    }

    displayAlerts(alerts) {
        const container = document.getElementById('alerts-container');
        if (!container) return;

        container.innerHTML = '';
        alerts.forEach(alert => {
            const alertElement = this.createAlertElement(alert);
            container.appendChild(alertElement);
        });
    }

    createAlertElement(alert) {
        const div = document.createElement('div');
        div.className = `alert alert-${alert.type} alert-dismissible fade show`;
        div.innerHTML = `
            <strong>${alert.title}</strong>
            <p>${alert.message}</p>
            ${alert.action ? `<button class="btn btn-sm btn-outline-primary" onclick="${alert.action}">إجراء</button>` : ''}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        return div;
    }

    // Dashboard integration
    updateDashboard(data) {
        this.generateInsights(data).then(insights => {
            this.generateAlerts(insights);
            this.updateCharts(insights);
        });

        this.generatePredictions(data).then(predictions => {
            this.updatePredictions(predictions);
        });
    }

    updateCharts(insights) {
        // Update chart data based on insights
        insights.forEach(insight => {
            if (insight.chartData) {
                this.updateChart(insight.chartId, insight.chartData);
            }
        });
    }

    updatePredictions(predictions) {
        const container = document.getElementById('predictions-container');
        if (!container) return;

        container.innerHTML = '';
        predictions.forEach(prediction => {
            const card = this.createPredictionCard(prediction);
            container.appendChild(card);
        });
    }

    createPredictionCard(prediction) {
        const div = document.createElement('div');
        div.className = 'col-md-4';
        div.innerHTML = `
            <div class="card prediction-card">
                <div class="card-body">
                    <h5 class="card-title">${prediction.title}</h5>
                    <p class="card-text">
                        <strong>الحالي:</strong> ${prediction.current}<br>
                        <strong>المتوقع:</strong> ${prediction.predicted}<br>
                        <strong>الثقة:</strong> ${prediction.confidence}%
                    </p>
                    <div class="progress">
                        <div class="progress-bar" style="width: ${prediction.confidence}%"></div>
                    </div>
                </div>
            </div>
        `;
        return div;
    }
}

// Initialize AI System
const aiSystem = new AIInsightsSystem();
aiSystem.initializeModels();

// Global functions
async function generateAIInsights() {
    const data = await fetchAllData();
    const insights = await aiSystem.generateInsights(data);
    const predictions = await aiSystem.generatePredictions(data);
    
    return { insights, predictions };
}

async function fetchAllData() {
    return {
        projects: await loadProjects(),
        tenders: await loadTenders(),
        financial: await loadFinancialData(),
        cashFlow: await loadCashFlow(),
        incomeStatement: await loadIncomeStatement()
    };
}

// Auto-refresh system
setInterval(async () => {
    if (document.visibilityState === 'visible') {
        const data = await fetchAllData();
        aiSystem.updateDashboard(data);
    }
}, 300000); // Update every 5 minutes