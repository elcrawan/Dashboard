// Financial Reporting System JavaScript

// Global variables
let financialData = {
    accounts: [],
    balanceSheet: [],
    incomeStatement: [],
    cashFlow: [],
    kpis: []
};

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
    loadFinancialData();
    setupEventListeners();
    initializeCharts();
});

// Load financial data from CSV files
async function loadFinancialData() {
    try {
        showLoading(true);
        
        // Load accounts
        const accountsResponse = await fetch('accounts.csv');
        const accountsText = await accountsResponse.text();
        financialData.accounts = parseCSV(accountsText);
        
        // Load balance sheet
        const balanceResponse = await fetch('balance_sheet.csv');
        const balanceText = await balanceResponse.text();
        financialData.balanceSheet = parseCSV(balanceText);
        
        // Load income statement
        const incomeResponse = await fetch('income_statement.csv');
        const incomeText = await incomeResponse.text();
        financialData.incomeStatement = parseCSV(incomeText);
        
        // Load cash flow
        const cashFlowResponse = await fetch('cash_flow.csv');
        const cashFlowText = await cashFlowResponse.text();
        financialData.cashFlow = parseCSV(cashFlowText);
        
        // Load KPIs
        const kpiResponse = await fetch('financial_kpis.csv');
        const kpiText = await kpiResponse.text();
        financialData.kpis = parseCSV(kpiText);
        
        // Process and display data
        processFinancialData();
        updateDashboard();
        updateReports();
        
        showLoading(false);
    } catch (error) {
        console.error('Error loading financial data:', error);
        showLoading(false);
    }
}

// Parse CSV data
function parseCSV(csvText) {
    const lines = csvText.trim().split('\n');
    const headers = lines[0].split(',');
    const data = [];
    
    for (let i = 1; i < lines.length; i++) {
        const values = lines[i].split(',');
        const row = {};
        headers.forEach((header, index) => {
            row[header.trim()] = values[index] ? values[index].trim() : '';
        });
        data.push(row);
    }
    
    return data;
}

// Process financial data for calculations
function processFinancialData() {
    // Convert string numbers to actual numbers
    financialData.balanceSheet.forEach(item => {
        item.balance = parseFloat(item.balance) || 0;
        item.report_date = new Date(item.report_date);
    });
    
    financialData.incomeStatement.forEach(item => {
        item.amount = parseFloat(item.amount) || 0;
        item.report_date = new Date(item.report_date);
    });
    
    financialData.cashFlow.forEach(item => {
        item.operating_activities = parseFloat(item.operating_activities) || 0;
        item.investing_activities = parseFloat(item.investing_activities) || 0;
        item.financing_activities = parseFloat(item.financing_activities) || 0;
        item.net_change = parseFloat(item.net_change) || 0;
        item.report_date = new Date(item.report_date);
    });
    
    financialData.kpis.forEach(item => {
        item.revenue = parseFloat(item.revenue) || 0;
        item.net_income = parseFloat(item.net_income) || 0;
        item.total_assets = parseFloat(item.total_assets) || 0;
        item.total_liabilities = parseFloat(item.total_liabilities) || 0;
        item.equity = parseFloat(item.equity) || 0;
        item.current_ratio = parseFloat(item.current_ratio) || 0;
        item.debt_to_equity = parseFloat(item.debt_to_equity) || 0;
        item.gross_margin = parseFloat(item.gross_margin) || 0;
        item.net_margin = parseFloat(item.net_margin) || 0;
        item.roa = parseFloat(item.roa) || 0;
        item.roe = parseFloat(item.roe) || 0;
        item.report_date = new Date(item.report_date);
    });
}

// Update dashboard with latest data
function updateDashboard() {
    const latestKPI = financialData.kpis[financialData.kpis.length - 1];
    const previousKPI = financialData.kpis[financialData.kpis.length - 2];
    
    if (latestKPI) {
        document.getElementById('monthly-revenue').textContent = formatCurrency(latestKPI.revenue);
        document.getElementById('net-profit').textContent = formatCurrency(latestKPI.net_income);
        document.getElementById('total-assets').textContent = formatCurrency(latestKPI.total_assets);
        document.getElementById('current-ratio').textContent = latestKPI.current_ratio.toFixed(2);
    }
}

// Initialize charts
function initializeCharts() {
    createRevenueChart();
    createBalanceSheetChart();
    createCashFlowChart();
    createKPIChart();
}

// Create revenue chart
function createRevenueChart() {
    const ctx = document.getElementById('revenueChart').getContext('2d');
    
    const revenueData = financialData.incomeStatement.filter(item => 
        item.account_id === '4000' || item.account_id === '4100'
    );
    
    const labels = [...new Set(revenueData.map(item => item.report_date.toLocaleDateString('ar-SA')))];
    const revenueByMonth = {};
    
    revenueData.forEach(item => {
        const month = item.report_date.toLocaleDateString('ar-SA', { year: 'numeric', month: 'short' });
        if (!revenueByMonth[month]) revenueByMonth[month] = 0;
        revenueByMonth[month] += item.amount;
    });
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: Object.keys(revenueByMonth),
            datasets: [{
                label: 'الإيرادات',
                data: Object.values(revenueByMonth),
                borderColor: '#198754',
                backgroundColor: 'rgba(25, 135, 84, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return formatCurrency(value);
                        }
                    }
                }
            }
        }
    });
}

// Create balance sheet chart
function createBalanceSheetChart() {
    const ctx = document.getElementById('balanceSheetChart').getContext('2d');
    
    const latestData = financialData.balanceSheet.filter(item => 
        item.report_date.getTime() === financialData.balanceSheet[financialData.balanceSheet.length - 1].report_date.getTime()
    );
    
    const assets = latestData.filter(item => 
        getAccountType(item.account_id) === 'Assets'
    ).reduce((sum, item) => sum + item.balance, 0);
    
    const liabilities = latestData.filter(item => 
        getAccountType(item.account_id) === 'Liabilities'
    ).reduce((sum, item) => sum + item.balance, 0);
    
    const equity = latestData.filter(item => 
        getAccountType(item.account_id) === 'Equity'
    ).reduce((sum, item) => sum + item.balance, 0);
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['الأصول', 'الخصوم', 'حقوق الملكية'],
            datasets: [{
                data: [assets, liabilities, equity],
                backgroundColor: ['#0dcaf0', '#ffc107', '#198754']
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
}

// Create cash flow chart
function createCashFlowChart() {
    const ctx = document.getElementById('cashFlowChart').getContext('2d');
    
    const labels = financialData.cashFlow.map(item => 
        item.report_date.toLocaleDateString('ar-SA', { year: 'numeric', month: 'short' })
    );
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'الأنشطة التشغيلية',
                    data: financialData.cashFlow.map(item => item.operating_activities),
                    backgroundColor: '#198754'
                },
                {
                    label: 'الأنشطة الاستثمارية',
                    data: financialData.cashFlow.map(item => item.investing_activities),
                    backgroundColor: '#dc3545'
                },
                {
                    label: 'الأنشطة التمويلية',
                    data: financialData.cashFlow.map(item => item.financing_activities),
                    backgroundColor: '#0dcaf0'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return formatCurrency(value);
                        }
                    }
                }
            }
        }
    });
}

// Create KPI chart
function createKPIChart() {
    const ctx = document.getElementById('kpiChart').getContext('2d');
    
    const labels = financialData.kpis.map(item => 
        item.report_date.toLocaleDateString('ar-SA', { year: 'numeric', month: 'short' })
    );
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'نسبة الربح الإجمالي',
                    data: financialData.kpis.map(item => item.gross_margin),
                    borderColor: '#198754',
                    yAxisID: 'y'
                },
                {
                    label: 'نسبة الربح الصافي',
                    data: financialData.kpis.map(item => item.net_margin),
                    borderColor: '#0dcaf0',
                    yAxisID: 'y'
                },
                {
                    label: 'عائد على الأصول',
                    data: financialData.kpis.map(item => item.roa),
                    borderColor: '#ffc107',
                    yAxisID: 'y1'
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                mode: 'index',
                intersect: false,
            },
            scales: {
                y: {
                    type: 'linear',
                    display: true,
                    position: 'left',
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                },
                y1: {
                    type: 'linear',
                    display: true,
                    position: 'right',
                    grid: {
                        drawOnChartArea: false,
                    },
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                }
            }
        }
    });
}

// Update reports section
function updateReports() {
    updateBalanceSheetReport();
    updateIncomeStatementReport();
    updateCashFlowReport();
}

// Update balance sheet report
function updateBalanceSheetReport() {
    const tbody = document.querySelector('#balance-sheet-table tbody');
    tbody.innerHTML = '';
    
    const latestDate = financialData.balanceSheet[financialData.balanceSheet.length - 1].report_date;
    const latestData = financialData.balanceSheet.filter(item => 
        item.report_date.getTime() === latestDate.getTime()
    );
    
    let totalAssets = 0;
    let totalLiabilities = 0;
    let totalEquity = 0;
    
    // Assets
    const assets = latestData.filter(item => getAccountType(item.account_id) === 'Assets');
    assets.forEach(item => {
        const account = financialData.accounts.find(a => a.account_id === item.account_id);
        const row = tbody.insertRow();
        row.innerHTML = `
            <td>${account.account_name}</td>
            <td class="text-end">${formatCurrency(item.balance)}</td>
        `;
        totalAssets += item.balance;
    });
    
    // Add total assets
    const assetsRow = tbody.insertRow();
    assetsRow.innerHTML = `
        <td><strong>إجمالي الأصول</strong></td>
        <td class="text-end"><strong>${formatCurrency(totalAssets)}</strong></td>
    `;
    assetsRow.className = 'table-active';
    
    // Liabilities
    const liabilities = latestData.filter(item => getAccountType(item.account_id) === 'Liabilities');
    liabilities.forEach(item => {
        const account = financialData.accounts.find(a => a.account_id === item.account_id);
        const row = tbody.insertRow();
        row.innerHTML = `
            <td>${account.account_name}</td>
            <td class="text-end">${formatCurrency(item.balance)}</td>
        `;
        totalLiabilities += item.balance;
    });
    
    // Add total liabilities
    const liabilitiesRow = tbody.insertRow();
    liabilitiesRow.innerHTML = `
        <td><strong>إجمالي الخصوم</strong></td>
        <td class="text-end"><strong>${formatCurrency(totalLiabilities)}</strong></td>
    `;
    liabilitiesRow.className = 'table-active';
    
    // Equity
    const equity = latestData.filter(item => getAccountType(item.account_id) === 'Equity');
    equity.forEach(item => {
        const account = financialData.accounts.find(a => a.account_id === item.account_id);
        const row = tbody.insertRow();
        row.innerHTML = `
            <td>${account.account_name}</td>
            <td class="text-end">${formatCurrency(item.balance)}</td>
        `;
        totalEquity += item.balance;
    });
    
    // Add total equity
    const equityRow = tbody.insertRow();
    equityRow.innerHTML = `
        <td><strong>إجمالي حقوق الملكية</strong></td>
        <td class="text-end"><strong>${formatCurrency(totalEquity)}</strong></td>
    `;
    equityRow.className = 'table-active';
    
    // Add total liabilities and equity
    const totalRow = tbody.insertRow();
    totalRow.innerHTML = `
        <td><strong>إجمالي الخصوم وحقوق الملكية</strong></td>
        <td class="text-end"><strong>${formatCurrency(totalLiabilities + totalEquity)}</strong></td>
    `;
    totalRow.className = 'table-primary';
}

// Update income statement report
function updateIncomeStatementReport() {
    const tbody = document.querySelector('#income-statement-table tbody');
    tbody.innerHTML = '';
    
    const latestDate = financialData.incomeStatement[financialData.incomeStatement.length - 1].report_date;
    const latestData = financialData.incomeStatement.filter(item => 
        item.report_date.getTime() === latestDate.getTime()
    );
    
    let totalRevenue = 0;
    let totalExpenses = 0;
    
    // Revenue
    const revenue = latestData.filter(item => getAccountType(item.account_id) === 'Revenue');
    revenue.forEach(item => {
        const account = financialData.accounts.find(a => a.account_id === item.account_id);
        const row = tbody.insertRow();
        row.innerHTML = `
            <td>${account.account_name}</td>
            <td class="text-end">${formatCurrency(item.amount)}</td>
        `;
        totalRevenue += item.amount;
    });
    
    // Add total revenue
    const revenueRow = tbody.insertRow();
    revenueRow.innerHTML = `
        <td><strong>إجمالي الإيرادات</strong></td>
        <td class="text-end"><strong>${formatCurrency(totalRevenue)}</strong></td>
    `;
    revenueRow.className = 'table-success';
    
    // Expenses
    const expenses = latestData.filter(item => getAccountType(item.account_id) === 'Expenses');
    expenses.forEach(item => {
        const account = financialData.accounts.find(a => a.account_id === item.account_id);
        const row = tbody.insertRow();
        row.innerHTML = `
            <td>${account.account_name}</td>
            <td class="text-end">${formatCurrency(item.amount)}</td>
        `;
        totalExpenses += item.amount;
    });
    
    // Add total expenses
    const expensesRow = tbody.insertRow();
    expensesRow.innerHTML = `
        <td><strong>إجمالي المصاريف</strong></td>
        <td class="text-end"><strong>${formatCurrency(totalExpenses)}</strong></td>
    `;
    expensesRow.className = 'table-danger';
    
    // Add net income
    const netIncomeRow = tbody.insertRow();
    netIncomeRow.innerHTML = `
        <td><strong>صافي الربح</strong></td>
        <td class="text-end"><strong>${formatCurrency(totalRevenue - totalExpenses)}</strong></td>
    `;
    netIncomeRow.className = 'table-primary';
}

// Update cash flow report
function updateCashFlowReport() {
    const tbody = document.querySelector('#cash-flow-table tbody');
    tbody.innerHTML = '';
    
    financialData.cashFlow.forEach(item => {
        const row = tbody.insertRow();
        row.innerHTML = `
            <td>${item.report_date.toLocaleDateString('ar-SA')}</td>
            <td class="text-end">${formatCurrency(item.operating_activities)}</td>
            <td class="text-end">${formatCurrency(item.investing_activities)}</td>
            <td class="text-end">${formatCurrency(item.financing_activities)}</td>
            <td class="text-end">${formatCurrency(item.net_change)}</td>
        `;
    });
}

// Helper function to get account type
function getAccountType(accountId) {
    const account = financialData.accounts.find(a => a.account_id === accountId);
    return account ? account.account_type : '';
}

// Format currency
function formatCurrency(amount) {
    return new Intl.NumberFormat('ar-SA', {
        style: 'currency',
        currency: 'SAR',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(amount);
}

// Setup event listeners
function setupEventListeners() {
    // Tab navigation
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const target = this.getAttribute('href');
            showSection(target);
        });
    });
    
    // File upload
    document.getElementById('csvFile').addEventListener('change', handleFileUpload);
    
    // Date range filter
    document.getElementById('dateRange').addEventListener('change', filterByDateRange);
}

// Show specific section
function showSection(target) {
    // Hide all sections
    document.querySelectorAll('section').forEach(section => {
        section.style.display = 'none';
    });
    
    // Show target section
    document.querySelector(target).style.display = 'block';
    
    // Update active nav link
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });
    document.querySelector(`a[href="${target}"]`).classList.add('active');
}

// Handle file upload
function handleFileUpload(event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const csv = e.target.result;
            // Process uploaded CSV data
            console.log('File uploaded:', file.name);
            // Here you would implement CSV processing logic
        };
        reader.readAsText(file);
    }
}

// Filter data by date range
function filterByDateRange() {
    const range = document.getElementById('dateRange').value;
    // Implement date range filtering
    console.log('Filtering by date range:', range);
}

// Export data
function exportData() {
    // Create a comprehensive export
    const exportData = {
        accounts: financialData.accounts,
        balanceSheet: financialData.balanceSheet,
        incomeStatement: financialData.incomeStatement,
        cashFlow: financialData.cashFlow,
        kpis: financialData.kpis,
        exportDate: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(exportData, null, 2)], {
        type: 'application/json'
    });
    
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `financial_report_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
}

// Import data
function importData() {
    document.getElementById('csvFile').click();
}

// Show/hide loading
function showLoading(show) {
    const loadingElements = document.querySelectorAll('.loading');
    loadingElements.forEach(el => {
        el.style.display = show ? 'inline-block' : 'none';
    });
}

// Initialize tooltips
function initializeTooltips() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

// Responsive chart resizing
window.addEventListener('resize', function() {
    // Resize charts if needed
    Chart.helpers.each(Chart.instances, function(instance) {
        instance.resize();
    });
});