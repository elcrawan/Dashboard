-- Construction Project Management Database Schema
-- Supports MySQL/PostgreSQL with UAE Construction Industry Standards

-- Projects Table
CREATE TABLE projects (
    project_id VARCHAR(20) PRIMARY KEY,
    project_name VARCHAR(255) NOT NULL,
    project_type ENUM('residential', 'commercial', 'industrial', 'infrastructure', 'government'),
    client_name VARCHAR(255),
    client_contact VARCHAR(100),
    client_email VARCHAR(255),
    project_location VARCHAR(500),
    contract_value DECIMAL(15,2),
    start_date DATE,
    expected_end_date DATE,
    actual_end_date DATE,
    project_status ENUM('planning', 'active', 'on_hold', 'completed', 'cancelled'),
    project_manager VARCHAR(100),
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tenders Table
CREATE TABLE tenders (
    tender_id VARCHAR(20) PRIMARY KEY,
    project_id VARCHAR(20),
    tender_name VARCHAR(255),
    tender_type ENUM('public', 'private', 'invited'),
    submission_deadline DATE,
    opening_date DATE,
    estimated_value DECIMAL(15,2),
    tender_status ENUM('draft', 'submitted', 'awarded', 'rejected', 'cancelled'),
    bid_amount DECIMAL(15,2),
    bid_submission_date DATE,
    bid_result_date DATE,
    notes TEXT,
    FOREIGN KEY (project_id) REFERENCES projects(project_id)
);

-- Quantity Takeoff Table
CREATE TABLE quantity_takeoff (
    takeoff_id INT AUTO_INCREMENT PRIMARY KEY,
    project_id VARCHAR(20),
    item_code VARCHAR(50),
    item_description VARCHAR(500),
    unit VARCHAR(20),
    quantity DECIMAL(12,3),
    unit_price DECIMAL(12,2),
    total_price DECIMAL(15,2),
    category VARCHAR(100),
    subcategory VARCHAR(100),
    specifications TEXT,
    FOREIGN KEY (project_id) REFERENCES projects(project_id)
);

-- Quotations Table
CREATE TABLE quotations (
    quotation_id VARCHAR(20) PRIMARY KEY,
    project_id VARCHAR(20),
    quotation_date DATE,
    validity_period INT,
    total_amount DECIMAL(15,2),
    vat_amount DECIMAL(12,2),
    grand_total DECIMAL(15,2),
    terms_conditions TEXT,
    status ENUM('draft', 'sent', 'accepted', 'rejected', 'expired'),
    FOREIGN KEY (project_id) REFERENCES projects(project_id)
);

-- Contracts Table
CREATE TABLE contracts (
    contract_id VARCHAR(20) PRIMARY KEY,
    project_id VARCHAR(20),
    contract_number VARCHAR(50),
    contract_date DATE,
    contract_value DECIMAL(15,2),
    advance_payment DECIMAL(12,2),
    retention_percentage DECIMAL(5,2),
    performance_bond DECIMAL(12,2),
    contract_duration INT,
    penalty_clause TEXT,
    payment_terms TEXT,
    contract_status ENUM('draft', 'signed', 'active', 'completed', 'terminated'),
    FOREIGN KEY (project_id) REFERENCES projects(project_id)
);

-- Project Costs Table
CREATE TABLE project_costs (
    cost_id INT AUTO_INCREMENT PRIMARY KEY,
    project_id VARCHAR(20),
    cost_category ENUM('materials', 'labor', 'equipment', 'subcontractor', 'overhead', 'other'),
    cost_type ENUM('direct', 'indirect'),
    description VARCHAR(500),
    amount DECIMAL(12,2),
    cost_date DATE,
    vendor_name VARCHAR(255),
    invoice_number VARCHAR(100),
    payment_status ENUM('pending', 'paid', 'partial'),
    notes TEXT,
    FOREIGN KEY (project_id) REFERENCES projects(project_id)
);

-- Work Progress Tracking
CREATE TABLE work_progress (
    progress_id INT AUTO_INCREMENT PRIMARY KEY,
    project_id VARCHAR(20),
    work_item VARCHAR(255),
    planned_quantity DECIMAL(12,3),
    actual_quantity DECIMAL(12,3),
    planned_cost DECIMAL(12,2),
    actual_cost DECIMAL(12,2),
    completion_percentage DECIMAL(5,2),
    progress_date DATE,
    notes TEXT,
    FOREIGN KEY (project_id) REFERENCES projects(project_id)
);

-- Client Payments
CREATE TABLE client_payments (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    project_id VARCHAR(20),
    payment_date DATE,
    payment_amount DECIMAL(12,2),
    payment_type ENUM('advance', 'milestone', 'final', 'retention'),
    invoice_number VARCHAR(100),
    payment_status ENUM('pending', 'received', 'partial'),
    notes TEXT,
    FOREIGN KEY (project_id) REFERENCES projects(project_id)
);

-- Suppliers/Vendors
CREATE TABLE suppliers (
    supplier_id VARCHAR(20) PRIMARY KEY,
    supplier_name VARCHAR(255),
    contact_person VARCHAR(100),
    phone VARCHAR(50),
    email VARCHAR(255),
    address TEXT,
    supplier_type ENUM('materials', 'equipment', 'subcontractor', 'services'),
    credit_limit DECIMAL(12,2),
    payment_terms VARCHAR(100),
    status ENUM('active', 'inactive', 'blocked')
);

-- Supplier Payments
CREATE TABLE supplier_payments (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    project_id VARCHAR(20),
    supplier_id VARCHAR(20),
    invoice_number VARCHAR(100),
    invoice_amount DECIMAL(12,2),
    paid_amount DECIMAL(12,2),
    payment_date DATE,
    payment_method ENUM('cash', 'cheque', 'bank_transfer', 'credit'),
    notes TEXT,
    FOREIGN KEY (project_id) REFERENCES projects(project_id),
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id)
);

-- Project Milestones
CREATE TABLE project_milestones (
    milestone_id INT AUTO_INCREMENT PRIMARY KEY,
    project_id VARCHAR(20),
    milestone_name VARCHAR(255),
    planned_date DATE,
    actual_date DATE,
    completion_status ENUM('pending', 'completed', 'delayed'),
    payment_percentage DECIMAL(5,2),
    payment_amount DECIMAL(12,2),
    notes TEXT,
    FOREIGN KEY (project_id) REFERENCES projects(project_id)
);

-- Project Documents
CREATE TABLE project_documents (
    document_id INT AUTO_INCREMENT PRIMARY KEY,
    project_id VARCHAR(20),
    document_type ENUM('contract', 'drawing', 'specification', 'permit', 'report', 'other'),
    document_name VARCHAR(255),
    file_path VARCHAR(500),
    upload_date DATE,
    version VARCHAR(20),
    description TEXT,
    FOREIGN KEY (project_id) REFERENCES projects(project_id)
);

-- Project Profit/Loss Analysis
CREATE TABLE project_profit_loss (
    analysis_id INT AUTO_INCREMENT PRIMARY KEY,
    project_id VARCHAR(20),
    total_revenue DECIMAL(15,2),
    total_costs DECIMAL(15,2),
    gross_profit DECIMAL(12,2),
    net_profit DECIMAL(12,2),
    profit_margin DECIMAL(5,2),
    analysis_date DATE,
    notes TEXT,
    FOREIGN KEY (project_id) REFERENCES projects(project_id)
);

-- Indexes for performance
CREATE INDEX idx_projects_status ON projects(project_status);
CREATE INDEX idx_projects_client ON projects(client_name);
CREATE INDEX idx_project_costs_project ON project_costs(project_id);
CREATE INDEX idx_work_progress_project ON work_progress(project_id);
CREATE INDEX idx_client_payments_project ON client_payments(project_id);
CREATE INDEX idx_supplier_payments_project ON supplier_payments(project_id);
CREATE INDEX idx_tenders_project ON tenders(project_id);