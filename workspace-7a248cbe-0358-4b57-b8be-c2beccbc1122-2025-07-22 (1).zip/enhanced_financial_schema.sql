-- Enhanced Financial Database Schema with UAE Tax System
-- Supports MySQL/PostgreSQL

-- Chart of Accounts (Enhanced)
CREATE TABLE accounts (
    account_id VARCHAR(20) PRIMARY KEY,
    account_name VARCHAR(255) NOT NULL,
    account_type VARCHAR(50) NOT NULL,
    account_category VARCHAR(50),
    parent_account VARCHAR(20),
    tax_category VARCHAR(50), -- VAT, Income Tax, etc.
    is_taxable BOOLEAN DEFAULT FALSE,
    tax_rate DECIMAL(5,2) DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_date DATE DEFAULT CURRENT_DATE,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- UAE Tax Configuration
CREATE TABLE tax_configuration (
    id SERIAL PRIMARY KEY,
    tax_type VARCHAR(50) NOT NULL, -- VAT, Income Tax, Excise Tax
    tax_rate DECIMAL(5,2) NOT NULL,
    effective_date DATE NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE
);

-- Tax Transactions
CREATE TABLE tax_transactions (
    id SERIAL PRIMARY KEY,
    transaction_date DATE NOT NULL,
    tax_type VARCHAR(50) NOT NULL,
    taxable_amount DECIMAL(15,2) NOT NULL,
    tax_amount DECIMAL(15,2) NOT NULL,
    tax_rate DECIMAL(5,2) NOT NULL,
    account_id VARCHAR(20),
    invoice_number VARCHAR(50),
    description TEXT,
    filing_period VARCHAR(20), -- Monthly, Quarterly, Annual
    is_paid BOOLEAN DEFAULT FALSE,
    payment_date DATE,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (account_id) REFERENCES accounts(account_id)
);

-- VAT Returns (UAE)
CREATE TABLE vat_returns (
    id SERIAL PRIMARY KEY,
    tax_period VARCHAR(20) NOT NULL, -- MM-YYYY
    vat_on_sales DECIMAL(15,2) DEFAULT 0,
    vat_on_expenses DECIMAL(15,2) DEFAULT 0,
    net_vat_payable DECIMAL(15,2) DEFAULT 0,
    total_sales DECIMAL(15,2) DEFAULT 0,
    total_expenses DECIMAL(15,2) DEFAULT 0,
    filing_date DATE,
    payment_due_date DATE,
    status VARCHAR(20) DEFAULT 'Pending', -- Pending, Filed, Paid
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Income Tax Returns (UAE)
CREATE TABLE income_tax_returns (
    id SERIAL PRIMARY KEY,
    tax_year INT NOT NULL,
    total_revenue DECIMAL(15,2) DEFAULT 0,
    total_expenses DECIMAL(15,2) DEFAULT 0,
    taxable_income DECIMAL(15,2) DEFAULT 0,
    tax_amount DECIMAL(15,2) DEFAULT 0,
    tax_rate DECIMAL(5,2) DEFAULT 9.0,
    filing_date DATE,
    payment_due_date DATE,
    status VARCHAR(20) DEFAULT 'Pending',
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Enhanced Financial Transactions
CREATE TABLE transactions (
    transaction_id VARCHAR(50) PRIMARY KEY,
    transaction_date DATE NOT NULL,
    account_id VARCHAR(20) NOT NULL,
    description TEXT,
    debit_amount DECIMAL(15,2) DEFAULT 0,
    credit_amount DECIMAL(15,2) DEFAULT 0,
    vat_amount DECIMAL(15,2) DEFAULT 0,
    tax_amount DECIMAL(15,2) DEFAULT 0,
    net_amount DECIMAL(15,2) DEFAULT 0,
    reference_number VARCHAR(50),
    invoice_number VARCHAR(50),
    customer_vendor VARCHAR(255),
    tax_category VARCHAR(50),
    is_tax_inclusive BOOLEAN DEFAULT FALSE,
    created_by VARCHAR(100),
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (account_id) REFERENCES accounts(account_id)
);

-- Financial Ratios
CREATE TABLE financial_ratios (
    id SERIAL PRIMARY KEY,
    report_date DATE NOT NULL,
    current_ratio DECIMAL(5,2),
    quick_ratio DECIMAL(5,2),
    debt_to_equity DECIMAL(5,2),
    debt_to_assets DECIMAL(5,2),
    gross_margin DECIMAL(5,2),
    net_margin DECIMAL(5,2),
    roa DECIMAL(5,2),
    roe DECIMAL(5,2),
    asset_turnover DECIMAL(5,2),
    inventory_turnover DECIMAL(5,2),
    receivables_turnover DECIMAL(5,2),
    interest_coverage DECIMAL(5,2),
    operating_margin DECIMAL(5,2),
    ebitda_margin DECIMAL(5,2),
    working_capital DECIMAL(15,2),
    free_cash_flow DECIMAL(15,2),
    period_type VARCHAR(20)
);

-- Email Templates
CREATE TABLE email_templates (
    id SERIAL PRIMARY KEY,
    template_name VARCHAR(100) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    body_template TEXT NOT NULL,
    template_type VARCHAR(50), -- Tax Reminder, Report, Alert
    is_active BOOLEAN DEFAULT TRUE
);

-- Email Notifications
CREATE TABLE email_notifications (
    id SERIAL PRIMARY KEY,
    recipient_email VARCHAR(255) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    body TEXT NOT NULL,
    notification_type VARCHAR(50),
    scheduled_date DATE,
    sent_date TIMESTAMP,
    status VARCHAR(20) DEFAULT 'Pending', -- Pending, Sent, Failed
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- API Keys for Integration
CREATE TABLE api_keys (
    id SERIAL PRIMARY KEY,
    api_key VARCHAR(255) UNIQUE NOT NULL,
    client_name VARCHAR(255) NOT NULL,
    permissions JSON,
    is_active BOOLEAN DEFAULT TRUE,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_date DATE
);

-- Audit Log
CREATE TABLE audit_log (
    id SERIAL PRIMARY KEY,
    table_name VARCHAR(100) NOT NULL,
    record_id VARCHAR(50),
    action VARCHAR(20) NOT NULL, -- INSERT, UPDATE, DELETE
    old_values JSON,
    new_values JSON,
    changed_by VARCHAR(100),
    changed_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert UAE Tax Configuration
INSERT INTO tax_configuration (tax_type, tax_rate, effective_date, description) VALUES
('VAT', 5.00, '2018-01-01', 'UAE Value Added Tax'),
('Income Tax', 9.00, '2023-06-01', 'UAE Corporate Income Tax'),
('Excise Tax', 50.00, '2017-10-01', 'UAE Excise Tax on Tobacco'),
('Excise Tax', 100.00, '2017-10-01', 'UAE Excise Tax on Energy Drinks');

-- Insert Email Templates
INSERT INTO email_templates (template_name, subject, body_template, template_type) VALUES
('VAT Reminder', 'تذكير بموعد تقديم إقرار ضريبة القيمة المضافة', 
 'عزيزي العميل،\n\nتذكير بأن موعد تقديم إقرار ضريبة القيمة المضافة للفترة {tax_period} هو {due_date}.\n\nالمبلغ المستحق: {tax_amount} درهم\n\nيرجى التأكد من تقديم الإقرار في الوقت المحدد لتجنب الغرامات.\n\nمع تحيات فريق المالية', 'Tax Reminder'),

('Income Tax Reminder', 'تذكير بموعد تقديم إقرار ضريبة الدخل',
 'عزيزي العميل،\n\nتذكير بأن موعد تقديم إقرار ضريبة الدخل للسنة المالية {tax_year} هو {due_date}.\n\nالضريبة المستحقة: {tax_amount} درهم\n\nيرجى التأكد من تقديم الإقرار في الوقت المحدد.\n\nمع تحيات فريق المالية', 'Tax Reminder'),

('Monthly Report', 'التقرير المالي الشهري - {report_month}',
 'عزيزي العميل،\n\nيرجى إيجاد التقرير المالي الشهري المرفق.\n\nملخص الأداء:\n- الإيرادات: {total_revenue} درهم\n- صافي الربح: {net_income} درهم\n- الضرائب المستحقة: {tax_amount} درهم\n\nمع تحيات فريق المالية', 'Report');