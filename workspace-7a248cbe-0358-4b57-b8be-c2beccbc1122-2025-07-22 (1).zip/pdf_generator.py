#!/usr/bin/env python3
"""
PDF Report Generator for Financial Reports
Supports Arabic text and UAE tax reports
"""

from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.enums import TA_CENTER, TA_RIGHT, TA_LEFT
import json
import csv
from datetime import datetime

class FinancialPDFGenerator:
    def __init__(self):
        self.styles = getSampleStyleSheet()
        self.setup_styles()
        
    def setup_styles(self):
        """Setup custom styles for Arabic text"""
        # Register Arabic font (using DejaVu Sans as fallback)
        try:
            pdfmetrics.registerFont(TTFont('DejaVu', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
        except:
            pass
            
        # Custom styles
        self.styles.add(ParagraphStyle(
            name='ArabicTitle',
            fontName='DejaVu',
            fontSize=18,
            alignment=TA_CENTER,
            spaceAfter=30
        ))
        
        self.styles.add(ParagraphStyle(
            name='ArabicHeader',
            fontName='DejaVu',
            fontSize=14,
            alignment=TA_RIGHT,
            spaceAfter=12
        ))
        
        self.styles.add(ParagraphStyle(
            name='ArabicNormal',
            fontName='DejaVu',
            fontSize=10,
            alignment=TA_RIGHT
        ))
    
    def load_financial_data(self):
        """Load financial data from CSV files"""
        data = {}
        
        # Load accounts
        try:
            with open('accounts.csv', 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                data['accounts'] = list(reader)
        except:
            data['accounts'] = []
            
        # Load balance sheet
        try:
            with open('balance_sheet.csv', 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                data['balance_sheet'] = list(reader)
        except:
            data['balance_sheet'] = []
            
        # Load income statement
        try:
            with open('income_statement.csv', 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                data['income_statement'] = list(reader)
        except:
            data['income_statement'] = []
            
        # Load UAE tax data
        try:
            with open('uae_tax_returns.csv', 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                data['tax_returns'] = list(reader)
        except:
            data['tax_returns'] = []
            
        return data
    
    def generate_balance_sheet_pdf(self, filename='balance_sheet_report.pdf'):
        """Generate balance sheet PDF report"""
        data = self.load_financial_data()
        
        doc = SimpleDocTemplate(filename, pagesize=A4)
        story = []
        
        # Title
        title = Paragraph("الميزانية العمومية", self.styles['ArabicTitle'])
        story.append(title)
        
        # Date
        date_str = datetime.now().strftime("%d/%m/%Y")
        date_para = Paragraph(f"تاريخ التقرير: {date_str}", self.styles['ArabicNormal'])
        story.append(date_para)
        story.append(Spacer(1, 20))
        
        # Assets section
        assets_header = Paragraph("الأصول", self.styles['ArabicHeader'])
        story.append(assets_header)
        
        assets_data = [['الحساب', 'المبلغ (درهم)']]
        total_assets = 0
        
        for item in data['balance_sheet']:
            if item['account_type'] == 'Assets':
                amount = float(item['amount'])
                assets_data.append([item['account_name'], f"{amount:,.2f}"])
                total_assets += amount
        
        assets_data.append(['إجمالي الأصول', f"{total_assets:,.2f}"])
        
        assets_table = Table(assets_data, colWidths=[3*inch, 2*inch])
        assets_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'DejaVu'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        story.append(assets_table)
        story.append(Spacer(1, 20))
        
        # Liabilities section
        liabilities_header = Paragraph("الخصوم", self.styles['ArabicHeader'])
        story.append(liabilities_header)
        
        liabilities_data = [['الحساب', 'المبلغ (درهم)']]
        total_liabilities = 0
        
        for item in data['balance_sheet']:
            if item['account_type'] == 'Liabilities':
                amount = float(item['amount'])
                liabilities_data.append([item['account_name'], f"{amount:,.2f}"])
                total_liabilities += amount
        
        liabilities_data.append(['إجمالي الخصوم', f"{total_liabilities:,.2f}"])
        
        liabilities_table = Table(liabilities_data, colWidths=[3*inch, 2*inch])
        liabilities_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'DejaVu'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        story.append(liabilities_table)
        story.append(Spacer(1, 20))
        
        # Equity section
        equity_header = Paragraph("حقوق الملكية", self.styles['ArabicHeader'])
        story.append(equity_header)
        
        equity_data = [['الحساب', 'المبلغ (درهم)']]
        total_equity = 0
        
        for item in data['balance_sheet']:
            if item['account_type'] == 'Equity':
                amount = float(item['amount'])
                equity_data.append([item['account_name'], f"{amount:,.2f}"])
                total_equity += amount
        
        equity_data.append(['إجمالي حقوق الملكية', f"{total_equity:,.2f}"])
        
        equity_table = Table(equity_data, colWidths=[3*inch, 2*inch])
        equity_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'DejaVu'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        story.append(equity_table)
        
        doc.build(story)
        return filename
    
    def generate_uae_tax_report(self, filename='uae_tax_report.pdf'):
        """Generate UAE tax report PDF"""
        data = self.load_financial_data()
        
        doc = SimpleDocTemplate(filename, pagesize=A4)
        story = []
        
        # Title
        title = Paragraph("تقرير الضرائب - دولة الإمارات العربية المتحدة", self.styles['ArabicTitle'])
        story.append(title)
        
        # VAT Report
        vat_header = Paragraph("تقرير ضريبة القيمة المضافة (5%)", self.styles['ArabicHeader'])
        story.append(vat_header)
        
        vat_data = [['الفترة', 'المبيعات الخاضعة', 'ضريبة القيمة المضافة', 'المشتريات الخاضعة', 'ضريبة المدخلات', 'الضريبة المستحقة']]
        
        total_vat_payable = 0
        for tax_return in data['tax_returns']:
            if tax_return['tax_type'] == 'VAT':
                vat_data.append([
                    tax_return['period'],
                    f"{float(tax_return['taxable_sales']):,.2f}",
                    f"{float(tax_return['vat_on_sales']):,.2f}",
                    f"{float(tax_return['taxable_purchases']):,.2f}",
                    f"{float(tax_return['vat_on_purchases']):,.2f}",
                    f"{float(tax_return['vat_payable']):,.2f}"
                ])
                total_vat_payable += float(tax_return['vat_payable'])
        
        vat_table = Table(vat_data, colWidths=[1.2*inch, 1.2*inch, 1.2*inch, 1.2*inch, 1.2*inch, 1.2*inch])
        vat_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'DejaVu'),
            ('FONTSIZE', (0, 0), (-1, 0), 8),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        story.append(vat_table)
        story.append(Spacer(1, 10))
        
        # Total VAT
        total_vat_para = Paragraph(f"إجمالي ضريبة القيمة المضافة المستحقة: {total_vat_payable:,.2f} درهم", self.styles['ArabicHeader'])
        story.append(total_vat_para)
        story.append(PageBreak())
        
        # Income Tax Report
        income_tax_header = Paragraph("تقرير ضريبة الدخل (9%)", self.styles['ArabicHeader'])
        story.append(income_tax_header)
        
        income_tax_data = [['الفترة', 'الدخل الخاضع', 'الإعفاء', 'الدخل الخاضع للضريبة', 'ضريبة الدخل']]
        
        for tax_return in data['tax_returns']:
            if tax_return['tax_type'] == 'Income Tax':
                income_tax_data.append([
                    tax_return['period'],
                    f"{float(tax_return['taxable_income']):,.2f}",
                    f"{float(tax_return['exemption']):,.2f}",
                    f"{float(tax_return['taxable_base']):,.2f}",
                    f"{float(tax_return['tax_amount']):,.2f}"
                ])
        
        income_tax_table = Table(income_tax_data, colWidths=[1.5*inch, 1.5*inch, 1.5*inch, 1.5*inch, 1.5*inch])
        income_tax_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'DejaVu'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        story.append(income_tax_table)
        
        doc.build(story)
        return filename

# Usage example
if __name__ == "__main__":
    generator = FinancialPDFGenerator()
    
    # Generate reports
    balance_sheet_pdf = generator.generate_balance_sheet_pdf()
    tax_report_pdf = generator.generate_uae_tax_report()
    
    print(f"Reports generated: {balance_sheet_pdf}, {tax_report_pdf}")