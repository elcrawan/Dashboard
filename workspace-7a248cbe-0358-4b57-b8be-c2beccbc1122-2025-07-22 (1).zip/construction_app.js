// Construction Project Management System
// Includes: Projects, Tenders, Quantity Takeoffs, Pricing, Contracts, Progress Tracking

// Global variables
let constructionData = {
    projects: [],
    tenders: [],
    quantities: [],
    contracts: [],
    suppliers: [],
    projectCosts: [],
    progressRecords: [],
    clientPayments: [],
    supplierPayments: [],
    milestones: []
};

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
    loadConstructionData();
    initializeDashboard();
    setupEventListeners();
});

// Load construction data
function loadConstructionData() {
    Promise.all([
        loadCSV('data/projects.csv'),
        loadCSV('data/tenders.csv'),
        loadCSV('data/quantities.csv'),
        loadCSV('data/contracts.csv'),
        loadCSV('data/suppliers.csv'),
        loadCSV('data/project_costs.csv'),
        loadCSV('data/progress_records.csv'),
        loadCSV('data/client_payments.csv'),
        loadCSV('data/supplier_payments.csv'),
        loadCSV('data/milestones.csv')
    ]).then(results => {
        constructionData.projects = results[0];
        constructionData.tenders = results[1];
        constructionData.quantities = results[2];
        constructionData.contracts = results[3];
        constructionData.suppliers = results[4];
        constructionData.projectCosts = results[5];
        constructionData.progressRecords = results[6];
        constructionData.clientPayments = results[7];
        constructionData.supplierPayments = results[8];
        constructionData.milestones = results[9];
        
        renderDashboard();
    }).catch(error => {
        console.error('Error loading construction data:', error);
    });
}

// Load CSV data
function loadCSV(filename) {
    return fetch(filename)
        .then(response => response.text())
        .then(text => {
            const lines = text.split('\n');
            const headers = lines[0].split(',');
            const data = [];
            
            for (let i = 1; i < lines.length; i++) {
                if (lines[i].trim()) {
                    const values = lines[i].split(',');
                    const row = {};
                    headers.forEach((header, index) => {
                        row[header.trim()] = values[index] ? values[index].trim() : '';
                    });
                    data.push(row);
                }
            }
            return data;
        });
}

// Initialize dashboard
function initializeDashboard() {
    updateProjectStats();
    renderProjectCards();
    renderProgressChart();
    renderFinancialChart();
    renderUpcomingMilestones();
    renderRecentActivities();
}

// Update project statistics
function updateProjectStats() {
    const totalProjects = constructionData.projects.length;
    const activeProjects = constructionData.projects.filter(p => p.status === 'Active').length;
    const completedProjects = constructionData.projects.filter(p => p.status === 'Completed').length;
    const totalRevenue = constructionData.projects.reduce((sum, p) => sum + parseFloat(p.contract_value || 0), 0);
    
    document.getElementById('total-projects').textContent = totalProjects;
    document.getElementById('active-projects').textContent = activeProjects;
    document.getElementById('completed-projects').textContent = completedProjects;
    document.getElementById('total-revenue').textContent = formatCurrency(totalRevenue);
}

// Render project cards
function renderProjectCards() {
    const container = document.getElementById('project-cards');
    if (!container) return;
    
    container.innerHTML = '';
    
    constructionData.projects.slice(0, 6).forEach(project => {
        const progress = calculateProjectProgress(project.id);
        const card = createProjectCard(project, progress);
        container.appendChild(card);
    });
}

// Create project card
function createProjectCard(project, progress) {
    const card = document.createElement('div');
    card.className = 'col-lg-4 col-md-6 mb-4';
    
    card.innerHTML = `
        <div class="card project-card">
            <div class="card-header">
                <h5 class="card-title mb-0">${project.name}</h5>
                <span class="status-badge status-${project.status.toLowerCase()}">${project.status}</span>
            </div>
            <div class="card-body">
                <p class="card-text"><strong>العميل:</strong> ${project.client_name}</p>
                <p class="card-text"><strong>قيمة العقد:</strong> ${formatCurrency(parseFloat(project.contract_value || 0))}</p>
                <p class="card-text"><strong>تاريخ البدء:</strong> ${formatDate(project.start_date)}</p>
                <p class="card-text"><strong>تاريخ الانتهاء:</strong> ${formatDate(project.end_date)}</p>
                
                <div class="progress mb-3">
                    <div class="progress-bar" role="progressbar" 
                         style="width: ${progress}%" 
                         aria-valuenow="${progress}" 
                         aria-valuemin="0" 
                         aria-valuemax="100">
                        ${progress}%
                    </div>
                </div>
                
                <div class="d-flex justify-content-between">
                    <button class="btn btn-sm btn-primary" onclick="viewProjectDetails('${project.id}')">
                        <i class="fas fa-eye"></i> عرض التفاصيل
                    </button>
                    <button class="btn btn-sm btn-success" onclick="updateProgress('${project.id}')">
                        <i class="fas fa-chart-line"></i> تحديث التقدم
                    </button>
                </div>
            </div>
        </div>
    `;
    
    return card;
}

// Calculate project progress
function calculateProjectProgress(projectId) {
    const projectCosts = constructionData.projectCosts.filter(pc => pc.project_id === projectId);
    const totalBudget = projectCosts.reduce((sum, pc) => sum + parseFloat(pc.budget_amount || 0), 0);
    const actualCost = projectCosts.reduce((sum, pc) => sum + parseFloat(pc.actual_cost || 0), 0);
    
    if (totalBudget === 0) return 0;
    return Math.min(Math.round((actualCost / totalBudget) * 100), 100);
}

// Render progress chart
function renderProgressChart() {
    const ctx = document.getElementById('progressChart');
    if (!ctx) return;
    
    const projects = constructionData.projects.slice(0, 5);
    const labels = projects.map(p => p.name);
    const progress = projects.map(p => calculateProjectProgress(p.id));
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'نسبة الإنجاز (%)',
                data: progress,
                backgroundColor: 'rgba(255, 107, 53, 0.8)',
                borderColor: 'rgba(255, 107, 53, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100
                }
            }
        }
    });
}

// Render financial chart
function renderFinancialChart() {
    const ctx = document.getElementById('financialChart');
    if (!ctx) return;
    
    const projects = constructionData.projects;
    const monthlyData = {};
    
    projects.forEach(project => {
        const month = new Date(project.start_date).toLocaleDateString('ar-SA', { year: 'numeric', month: 'short' });
        if (!monthlyData[month]) {
            monthlyData[month] = { revenue: 0, costs: 0 };
        }
        monthlyData[month].revenue += parseFloat(project.contract_value || 0);
    });
    
    constructionData.projectCosts.forEach(cost => {
        const month = new Date(cost.date).toLocaleDateString('ar-SA', { year: 'numeric', month: 'short' });
        if (monthlyData[month]) {
            monthlyData[month].costs += parseFloat(cost.actual_cost || 0);
        }
    });
    
    const labels = Object.keys(monthlyData);
    const revenue = labels.map(month => monthlyData[month].revenue);
    const costs = labels.map(month => monthlyData[month].costs);
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'الإيرادات',
                data: revenue,
                borderColor: 'rgba(46, 204, 113, 1)',
                backgroundColor: 'rgba(46, 204, 113, 0.2)',
                fill: true
            }, {
                label: 'التكاليف',
                data: costs,
                borderColor: 'rgba(231, 76, 60, 1)',
                backgroundColor: 'rgba(231, 76, 60, 0.2)',
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false
        }
    });
}

// Render upcoming milestones
function renderUpcomingMilestones() {
    const container = document.getElementById('upcoming-milestones');
    if (!container) return;
    
    const today = new Date();
    const upcomingMilestones = constructionData.milestones
        .filter(m => new Date(m.due_date) >= today)
        .sort((a, b) => new Date(a.due_date) - new Date(b.due_date))
        .slice(0, 5);
    
    container.innerHTML = '';
    
    upcomingMilestones.forEach(milestone => {
        const project = constructionData.projects.find(p => p.id === milestone.project_id);
        const item = document.createElement('div');
        item.className = 'timeline-item';
        
        item.innerHTML = `
            <h6>${milestone.name}</h6>
            <p class="mb-1"><strong>المشروع:</strong> ${project ? project.name : 'غير محدد'}</p>
            <p class="mb-1"><strong>التاريخ:</strong> ${formatDate(milestone.due_date)}</p>
            <p class="mb-0"><strong>الحالة:</strong> ${milestone.status}</p>
        `;
        
        container.appendChild(item);
    });
}

// Render recent activities
function renderRecentActivities() {
    const container = document.getElementById('recent-activities');
    if (!container) return;
    
    const activities = [
        ...constructionData.progressRecords.map(r => ({
            type: 'progress',
            date: r.date,
            description: `تحديث تقدم المشروع ${getProjectName(r.project_id)}`,
            details: `${r.completion_percentage}% مكتمل`
        })),
        ...constructionData.clientPayments.map(p => ({
            type: 'payment',
            date: p.payment_date,
            description: `دفعة عميل للمشروع ${getProjectName(p.project_id)}`,
            details: formatCurrency(parseFloat(p.amount || 0))
        }))
    ];
    
    activities.sort((a, b) => new Date(b.date) - new Date(a.date));
    const recentActivities = activities.slice(0, 5);
    
    container.innerHTML = '';
    
    recentActivities.forEach(activity => {
        const item = document.createElement('div');
        item.className = 'list-group-item';
        
        item.innerHTML = `
            <div class="d-flex w-100 justify-content-between">
                <h6 class="mb-1">${activity.description}</h6>
                <small>${formatDate(activity.date)}</small>
            </div>
            <p class="mb-1">${activity.details}</p>
        `;
        
        container.appendChild(item);
    });
}

// View project details
function viewProjectDetails(projectId) {
    const project = constructionData.projects.find(p => p.id === projectId);
    if (!project) return;
    
    // Populate project details modal
    document.getElementById('project-name').textContent = project.name;
    document.getElementById('project-client').textContent = project.client_name;
    document.getElementById('project-value').textContent = formatCurrency(parseFloat(project.contract_value || 0));
    document.getElementById('project-start').textContent = formatDate(project.start_date);
    document.getElementById('project-end').textContent = formatDate(project.end_date);
    
    // Show project details modal
    const modal = new bootstrap.Modal(document.getElementById('projectDetailsModal'));
    modal.show();
}

// Update project progress
function updateProgress(projectId) {
    // Show progress update modal
    document.getElementById('progress-project-id').value = projectId;
    const modal = new bootstrap.Modal(document.getElementById('progressUpdateModal'));
    modal.show();
}

// Setup event listeners
function setupEventListeners() {
    // Progress update form
    document.getElementById('progress-update-form')?.addEventListener('submit', function(e) {
        e.preventDefault();
        saveProgressUpdate();
    });
    
    // Tender management
    document.getElementById('tender-form')?.addEventListener('submit', function(e) {
        e.preventDefault();
        saveTender();
    });
    
    // Quantity takeoff
    document.getElementById('quantity-form')?.addEventListener('submit', function(e) {
        e.preventDefault();
        saveQuantity();
    });
}

// Save progress update
function saveProgressUpdate() {
    const projectId = document.getElementById('progress-project-id').value;
    const percentage = document.getElementById('progress-percentage').value;
    const notes = document.getElementById('progress-notes').value;
    
    // Add new progress record
    const newRecord = {
        id: Date.now().toString(),
        project_id: projectId,
        date: new Date().toISOString().split('T')[0],
        completion_percentage: percentage,
        notes: notes
    };
    
    constructionData.progressRecords.push(newRecord);
    
    // Update UI
    renderDashboard();
    
    // Close modal
    const modal = bootstrap.Modal.getInstance(document.getElementById('progressUpdateModal'));
    modal.hide();
    
    // Show success message
    showAlert('تم تحديث التقدم بنجاح', 'success');
}

// Utility functions
function formatCurrency(amount) {
    return new Intl.NumberFormat('ar-SA', {
        style: 'currency',
        currency: 'SAR'
    }).format(amount);
}

function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('ar-SA');
}

function getProjectName(projectId) {
    const project = constructionData.projects.find(p => p.id === projectId);
    return project ? project.name : 'غير محدد';
}

function showAlert(message, type) {
    const alertContainer = document.getElementById('alert-container');
    if (!alertContainer) return;
    
    const alert = document.createElement('div');
    alert.className = `alert alert-${type} alert-dismissible fade show`;
    alert.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    alertContainer.appendChild(alert);
    
    setTimeout(() => {
        alert.remove();
    }, 5000);
}

// Export functions
function exportProjectReport(projectId) {
    const project = constructionData.projects.find(p => p.id === projectId);
    if (!project) return;
    
    // Generate project report
    const report = {
        project: project,
        progress: calculateProjectProgress(projectId),
        costs: constructionData.projectCosts.filter(pc => pc.project_id === projectId),
        payments: constructionData.clientPayments.filter(cp => cp.project_id === projectId)
    };
    
    // Export as JSON
    const dataStr = JSON.stringify(report, null, 2);
    const dataBlob = new Blob([dataStr], {type: 'application/json'});
    const url = URL.createObjectURL(dataBlob);
    
    const link = document.createElement('a');
    link.href = url;
    link.download = `project-report-${project.name}.json`;
    link.click();
}

// Initialize tooltips
document.addEventListener('DOMContentLoaded', function() {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});