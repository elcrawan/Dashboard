#!/usr/bin/env python3
"""
Generate sample financial data using basic Python
"""

import csv
import json
import random
from datetime import datetime, timedelta

# Set random seed for reproducibility
random.seed(42)

# Chart of Accounts
accounts = [
    {"account_id": "1000", "account_name": "Cash and Cash Equivalents", "account_type": "Assets", "account_category": "Current Assets"},
    {"account_id": "1100", "account_name": "Accounts Receivable", "account_type": "Assets", "account_category": "Current Assets"},
    {"account_id": "1200", "account_name": "Inventory", "account_type": "Assets", "account_category": "Current Assets"},
    {"account_id": "1500", "account_name": "Property, Plant & Equipment", "account_type": "Assets", "account_category": "Fixed Assets"},
    {"account_id": "1600", "account_name": "Accumulated Depreciation", "account_type": "Assets", "account_category": "Fixed Assets"},
    {"account_id": "2000", "account_name": "Accounts Payable", "account_type": "Liabilities", "account_category": "Current Liabilities"},
    {"account_id": "2100", "account_name": "Short-term Debt", "account_type": "Liabilities", "account_category": "Current Liabilities"},
    {"account_id": "2200", "account_name": "Long-term Debt", "account_type": "Liabilities", "account_category": "Long-term Liabilities"},
    {"account_id": "3000", "account_name": "Common Stock", "account_type": "Equity", "account_category": "Shareholders Equity"},
    {"account_id": "3100", "account_name": "Retained Earnings", "account_type": "Equity", "account_category": "Shareholders Equity"},
    {"account_id": "4000", "account_name": "Sales Revenue", "account_type": "Revenue", "account_category": "Operating Revenue"},
    {"account_id": "4100", "account_name": "Service Revenue", "account_type": "Revenue", "account_category": "Operating Revenue"},
    {"account_id": "5000", "account_name": "Cost of Goods Sold", "account_type": "Expenses", "account_category": "Direct Costs"},
    {"account_id": "5100", "account_name": "Salaries and Wages", "account_type": "Expenses", "account_category": "Operating Expenses"},
    {"account_id": "5200", "account_name": "Rent Expense", "account_type": "Expenses", "account_category": "Operating Expenses"},
    {"account_id": "5300", "account_name": "Utilities Expense", "account_type": "Expenses", "account_category": "Operating Expenses"},
    {"account_id": "5400", "account_name": "Marketing Expense", "account_type": "Expenses", "account_category": "Operating Expenses"},
    {"account_id": "5500", "account_name": "Depreciation Expense", "account_type": "Expenses", "account_category": "Operating Expenses"}
]

# Save accounts to CSV
with open('accounts.csv', 'w', newline='', encoding='utf-8') as f:
    writer = csv.DictWriter(f, fieldnames=['account_id', 'account_name', 'account_type', 'account_category'])
    writer.writeheader()
    writer.writerows(accounts)

# Generate monthly data for 24 months
start_date = datetime(2023, 1, 1)
months = []
for i in range(24):
    months.append(start_date + timedelta(days=30*i))

# Generate balance sheet data
balance_sheet_data = []
for i, date in enumerate(months):
    # Base values with growth
    growth_factor = 1 + (i * 0.02)  # 2% monthly growth
    
    cash = max(50000 * growth_factor + random.uniform(-5000, 5000), 10000)
    monthly_revenue = 80000 * growth_factor + random.uniform(-10000, 10000)
    ar = max(monthly_revenue * 0.15 + random.uniform(-2000, 2000), 5000)
    inventory = max(monthly_revenue * 0.6 * 0.2 + random.uniform(-1000, 1000), 5000)
    ppe = max(200000 - (i * 2000) + random.uniform(-5000, 5000), 50000)
    
    ap = max(monthly_revenue * 0.1 + random.uniform(-1000, 1000), 2000)
    short_debt = max(30000 - (i * 500) + random.uniform(-2000, 2000), 5000)
    long_debt = max(100000 - (i * 1000) + random.uniform(-5000, 5000), 20000)
    
    retained_earnings = max((monthly_revenue - monthly_revenue * 0.6 - 25000) * (i + 1), 10000)
    
    balance_sheet_data.extend([
        {"report_date": date.strftime('%Y-%m-%d'), "account_id": "1000", "balance": round(cash, 2), "period_type": "Monthly"},
        {"report_date": date.strftime('%Y-%m-%d'), "account_id": "1100", "balance": round(ar, 2), "period_type": "Monthly"},
        {"report_date": date.strftime('%Y-%m-%d'), "account_id": "1200", "balance": round(inventory, 2), "period_type": "Monthly"},
        {"report_date": date.strftime('%Y-%m-%d'), "account_id": "1500", "balance": round(ppe, 2), "period_type": "Monthly"},
        {"report_date": date.strftime('%Y-%m-%d'), "account_id": "2000", "balance": round(ap, 2), "period_type": "Monthly"},
        {"report_date": date.strftime('%Y-%m-%d'), "account_id": "2100", "balance": round(short_debt, 2), "period_type": "Monthly"},
        {"report_date": date.strftime('%Y-%m-%d'), "account_id": "2200", "balance": round(long_debt, 2), "period_type": "Monthly"},
        {"report_date": date.strftime('%Y-%m-%d'), "account_id": "3100", "balance": round(retained_earnings, 2), "period_type": "Monthly"}
    ])

# Save balance sheet data
with open('balance_sheet.csv', 'w', newline='', encoding='utf-8') as f:
    writer = csv.DictWriter(f, fieldnames=['report_date', 'account_id', 'balance', 'period_type'])
    writer.writeheader()
    writer.writerows(balance_sheet_data)

# Generate income statement data
income_statement_data = []
for i, date in enumerate(months):
    growth_factor = 1 + (i * 0.02)
    
    revenue = 80000 * growth_factor + random.uniform(-10000, 10000)
    cogs = revenue * 0.6 + random.uniform(-2000, 2000)
    salaries = 15000 + random.uniform(-500, 500)
    rent = 3000
    utilities = 1000 + random.uniform(-100, 100)
    marketing = 2000 + random.uniform(-200, 200)
    depreciation = 2000
    
    income_statement_data.extend([
        {"report_date": date.strftime('%Y-%m-%d'), "account_id": "4000", "amount": round(revenue, 2), "period_type": "Monthly"},
        {"report_date": date.strftime('%Y-%m-%d'), "account_id": "5000", "amount": round(cogs, 2), "period_type": "Monthly"},
        {"report_date": date.strftime('%Y-%m-%d'), "account_id": "5100", "amount": round(salaries, 2), "period_type": "Monthly"},
        {"report_date": date.strftime('%Y-%m-%d'), "account_id": "5200", "amount": round(rent, 2), "period_type": "Monthly"},
        {"report_date": date.strftime('%Y-%m-%d'), "account_id": "5300", "amount": round(utilities, 2), "period_type": "Monthly"},
        {"report_date": date.strftime('%Y-%m-%d'), "account_id": "5400", "amount": round(marketing, 2), "period_type": "Monthly"},
        {"report_date": date.strftime('%Y-%m-%d'), "account_id": "5500", "amount": round(depreciation, 2), "period_type": "Monthly"}
    ])

# Save income statement data
with open('income_statement.csv', 'w', newline='', encoding='utf-8') as f:
    writer = csv.DictWriter(f, fieldnames=['report_date', 'account_id', 'amount', 'period_type'])
    writer.writeheader()
    writer.writerows(income_statement_data)

# Generate cash flow data
cash_flow_data = []
for i, date in enumerate(months):
    operating = 15000 * (1 + i * 0.01) + random.uniform(-2000, 2000)
    investing = -3000 - random.uniform(0, 1000)
    financing = -2000 - random.uniform(0, 500)
    net_change = operating + investing + financing
    
    cash_flow_data.append({
        "report_date": date.strftime('%Y-%m-%d'),
        "operating_activities": round(operating, 2),
        "investing_activities": round(investing, 2),
        "financing_activities": round(financing, 2),
        "net_change": round(net_change, 2),
        "period_type": "Monthly"
    })

# Save cash flow data
with open('cash_flow.csv', 'w', newline='', encoding='utf-8') as f:
    writer = csv.DictWriter(f, fieldnames=['report_date', 'operating_activities', 'investing_activities', 'financing_activities', 'net_change', 'period_type'])
    writer.writeheader()
    writer.writerows(cash_flow_data)

# Generate KPI data
kpi_data = []
for i, date in enumerate(months):
    # Get revenue from income statement
    revenue = 80000 * (1 + i * 0.02) + random.uniform(-10000, 10000)
    cogs = revenue * 0.6 + random.uniform(-2000, 2000)
    total_expenses = cogs + 15000 + 3000 + 1000 + 2000 + 2000 + random.uniform(-1000, 1000)
    
    net_income = revenue - total_expenses
    
    # Get balance sheet items
    cash = 50000 * (1 + i * 0.02) + random.uniform(-5000, 5000)
    ar = revenue * 0.15 + random.uniform(-2000, 2000)
    inventory = revenue * 0.6 * 0.2 + random.uniform(-1000, 1000)
    ppe = 200000 - (i * 2000) + random.uniform(-5000, 5000)
    
    ap = revenue * 0.1 + random.uniform(-1000, 1000)
    short_debt = 30000 - (i * 500) + random.uniform(-2000, 2000)
    long_debt = 100000 - (i * 1000) + random.uniform(-5000, 5000)
    
    retained_earnings = max((revenue - cogs - 25000) * (i + 1), 10000)
    
    total_assets = cash + ar + inventory + ppe
    total_liabilities = ap + short_debt + long_debt
    equity = retained_earnings
    
    current_ratio = (cash + ar + inventory) / max(ap + short_debt, 1)
    debt_to_equity = total_liabilities / max(equity, 1)
    gross_margin = ((revenue - cogs) / max(revenue, 1)) * 100
    net_margin = (net_income / max(revenue, 1)) * 100
    roa = (net_income / max(total_assets, 1)) * 100
    roe = (net_income / max(equity, 1)) * 100
    
    kpi_data.append({
        "report_date": date.strftime('%Y-%m-%d'),
        "revenue": round(revenue, 2),
        "net_income": round(net_income, 2),
        "total_assets": round(total_assets, 2),
        "total_liabilities": round(total_liabilities, 2),
        "equity": round(equity, 2),
        "current_ratio": round(max(current_ratio, 0), 2),
        "debt_to_equity": round(max(debt_to_equity, 0), 2),
        "gross_margin": round(max(gross_margin, 0), 2),
        "net_margin": round(max(net_margin, 0), 2),
        "roa": round(max(roa, 0), 2),
        "roe": round(max(roe, 0), 2)
    })

# Save KPI data
with open('financial_kpis.csv', 'w', newline='', encoding='utf-8') as f:
    writer = csv.DictWriter(f, fieldnames=['report_date', 'revenue', 'net_income', 'total_assets', 'total_liabilities', 'equity', 'current_ratio', 'debt_to_equity', 'gross_margin', 'net_margin', 'roa', 'roe'])
    writer.writeheader()
    writer.writerows(kpi_data)

print("Financial data generation completed!")
print(f"Generated {len(accounts)} accounts")
print(f"Generated {len(balance_sheet_data)} balance sheet records")
print(f"Generated {len(income_statement_data)} income statement records")
print(f"Generated {len(cash_flow_data)} cash flow records")
print(f"Generated {len(kpi_data)} KPI records")