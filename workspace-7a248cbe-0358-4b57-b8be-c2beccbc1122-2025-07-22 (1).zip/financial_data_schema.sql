-- Financial Database Schema
-- This represents a comprehensive financial reporting system

-- Chart of Accounts
CREATE TABLE accounts (
    account_id VARCHAR(20) PRIMARY KEY,
    account_name VARCHAR(255) NOT NULL,
    account_type VARCHAR(50) NOT NULL, -- Assets, Liabilities, Equity, Revenue, Expenses
    account_category VARCHAR(50), -- Current Assets, Fixed Assets, etc.
    parent_account VARCHAR(20),
    is_active BOOLEAN DEFAULT TRUE,
    created_date DATE DEFAULT CURRENT_DATE
);

-- Financial Transactions
CREATE TABLE transactions (
    transaction_id VARCHAR(50) PRIMARY KEY,
    transaction_date DATE NOT NULL,
    account_id VARCHAR(20) NOT NULL,
    description TEXT,
    debit_amount DECIMAL(15,2) DEFAULT 0,
    credit_amount DECIMAL(15,2) DEFAULT 0,
    reference_number VARCHAR(50),
    created_by VARCHAR(100),
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (account_id) REFERENCES accounts(account_id)
);

-- Balance Sheet Data
CREATE TABLE balance_sheet (
    id SERIAL PRIMARY KEY,
    report_date DATE NOT NULL,
    account_id VARCHAR(20) NOT NULL,
    balance DECIMAL(15,2) NOT NULL,
    period_type VARCHAR(20), -- Monthly, Quarterly, Yearly
    FOREIGN KEY (account_id) REFERENCES accounts(account_id)
);

-- Income Statement Data
CREATE TABLE income_statement (
    id SERIAL PRIMARY KEY,
    report_date DATE NOT NULL,
    account_id VARCHAR(20) NOT NULL,
    amount DECIMAL(15,2) NOT NULL,
    period_type VARCHAR(20),
    FOREIGN KEY (account_id) REFERENCES accounts(account_id)
);

-- Cash Flow Data
CREATE TABLE cash_flow (
    id SERIAL PRIMARY KEY,
    report_date DATE NOT NULL,
    operating_activities DECIMAL(15,2),
    investing_activities DECIMAL(15,2),
    financing_activities DECIMAL(15,2),
    net_change DECIMAL(15,2),
    period_type VARCHAR(20)
);

-- Financial KPIs
CREATE TABLE financial_kpis (
    id SERIAL PRIMARY KEY,
    report_date DATE NOT NULL,
    revenue DECIMAL(15,2),
    net_income DECIMAL(15,2),
    total_assets DECIMAL(15,2),
    total_liabilities DECIMAL(15,2),
    equity DECIMAL(15,2),
    current_ratio DECIMAL(5,2),
    debt_to_equity DECIMAL(5,2),
    gross_margin DECIMAL(5,2),
    net_margin DECIMAL(5,2),
    roa DECIMAL(5,2),
    roe DECIMAL(5,2)
);