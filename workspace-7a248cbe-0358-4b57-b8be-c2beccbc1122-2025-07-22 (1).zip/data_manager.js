// Data Management JavaScript

// Global variables
let currentData = {
    accounts: [],
    balanceSheet: [],
    incomeStatement: [],
    cashFlow: [],
    kpis: []
};

// Initialize data manager
document.addEventListener('DOMContentLoaded', function() {
    loadCurrentData();
    setupEventListeners();
    updateDataSummary();
});

// Load current data
async function loadCurrentData() {
    try {
        const accountsResponse = await fetch('accounts.csv');
        const accountsText = await accountsResponse.text();
        currentData.accounts = parseCSV(accountsText);
        
        const balanceResponse = await fetch('balance_sheet.csv');
        const balanceText = await balanceResponse.text();
        currentData.balanceSheet = parseCSV(balanceText);
        
        const incomeResponse = await fetch('income_statement.csv');
        const incomeText = await incomeResponse.text();
        currentData.incomeStatement = parseCSV(incomeText);
        
        const cashFlowResponse = await fetch('cash_flow.csv');
        const cashFlowText = await cashFlowResponse.text();
        currentData.cashFlow = parseCSV(cashFlowText);
        
        const kpiResponse = await fetch('financial_kpis.csv');
        const kpiText = await kpiResponse.text();
        currentData.kpis = parseCSV(kpiText);
        
        updateDataSummary();
    } catch (error) {
        console.error('Error loading data:', error);
    }
}

// Parse CSV data
function parseCSV(csvText) {
    const lines = csvText.trim().split('\n');
    const headers = lines[0].split(',');
    const data = [];
    
    for (let i = 1; i < lines.length; i++) {
        const values = lines[i].split(',');
        const row = {};
        headers.forEach((header, index) => {
            row[header.trim()] = values[index] ? values[index].trim() : '';
        });
        data.push(row);
    }
    
    return data;
}

// Setup event listeners
function setupEventListeners() {
    document.getElementById('importForm').addEventListener('submit', handleImport);
}

// Handle data import
async function handleImport(event) {
    event.preventDefault();
    
    const fileInput = document.getElementById('csvFile');
    const dataType = document.getElementById('dataType').value;
    const file = fileInput.files[0];
    
    if (!file) {
        alert('الرجاء اختيار ملف CSV');
        return;
    }
    
    showImportProgress(true);
    
    try {
        const text = await file.text();
        const data = parseCSV(text);
        
        // Validate data based on type
        const validation = validateImportData(data, dataType);
        
        if (validation.valid) {
            // Process and save data
            await processImportData(data, dataType);
            alert('تم استيراد البيانات بنجاح');
            location.reload();
        } else {
            alert('يوجد أخطاء في البيانات: ' + validation.errors.join(', '));
        }
    } catch (error) {
        alert('خطأ في استيراد البيانات: ' + error.message);
    } finally {
        showImportProgress(false);
    }
}

// Validate import data
function validateImportData(data, dataType) {
    const errors = [];
    const requiredFields = getRequiredFields(dataType);
    
    data.forEach((row, index) => {
        requiredFields.forEach(field => {
            if (!row[field] || row[field].trim() === '') {
                errors.push(`الصف ${index + 1}: الحقل ${field} مطلوب`);
            }
        });
    });
    
    return {
        valid: errors.length === 0,
        errors: errors
    };
}

// Get required fields for each data type
function getRequiredFields(dataType) {
    const fields = {
        accounts: ['account_id', 'account_name', 'account_type', 'account_category'],
        balance_sheet: ['report_date', 'account_id', 'balance'],
        income_statement: ['report_date', 'account_id', 'amount'],
        cash_flow: ['report_date', 'operating_activities', 'investing_activities', 'financing_activities'],
        kpis: ['report_date', 'revenue', 'net_income', 'total_assets']
    };
    
    return fields[dataType] || [];
}

// Process import data
async function processImportData(data, dataType) {
    // Convert data types
    data.forEach(row => {
        if (row.balance) row.balance = parseFloat(row.balance);
        if (row.amount) row.amount = parseFloat(row.amount);
        if (row.revenue) row.revenue = parseFloat(row.revenue);
        if (row.net_income) row.net_income = parseFloat(row.net_income);
        if (row.total_assets) row.total_assets = parseFloat(row.total_assets);
        if (row.operating_activities) row.operating_activities = parseFloat(row.operating_activities);
        if (row.investing_activities) row.investing_activities = parseFloat(row.investing_activities);
        if (row.financing_activities) row.financing_activities = parseFloat(row.financing_activities);
    });
    
    // Update current data
    currentData[dataType] = data;
    
    // Save to appropriate CSV file
    const filename = `${dataType}.csv`;
    const csvContent = convertToCSV(data);
    
    // In a real application, this would save to server
    console.log(`Would save to ${filename}:`, csvContent);
}

// Convert data to CSV
function convertToCSV(data) {
    if (data.length === 0) return '';
    
    const headers = Object.keys(data[0]);
    const csvRows = [headers.join(',')];
    
    data.forEach(row => {
        const values = headers.map(header => row[header] || '');
        csvRows.push(values.join(','));
    });
    
    return csvRows.join('\n');
}

// Show/hide import progress
function showImportProgress(show) {
    const progressDiv = document.getElementById('importProgress');
    if (show) {
        progressDiv.style.display = 'block';
    } else {
        progressDiv.style.display = 'none';
    }
}

// Export data
function exportData() {
    const exportType = document.getElementById('exportType').value;
    const exportFormat = document.getElementById('exportFormat').value;
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;
    
    let dataToExport = {};
    
    if (exportType === 'all') {
        dataToExport = currentData;
    } else {
        dataToExport[exportType] = currentData[exportType];
    }
    
    // Filter by date if provided
    if (startDate && endDate) {
        Object.keys(dataToExport).forEach(key => {
            dataToExport[key] = dataToExport[key].filter(item => {
                const itemDate = new Date(item.report_date || item.created_date);
                return itemDate >= new Date(startDate) && itemDate <= new Date(endDate);
            });
        });
    }
    
    // Export based on format
    switch (exportFormat) {
        case 'csv':
            exportToCSV(dataToExport);
            break;
        case 'json':
            exportToJSON(dataToExport);
            break;
        case 'excel':
            exportToExcel(dataToExport);
            break;
    }
}

// Export to CSV
function exportToCSV(data) {
    Object.keys(data).forEach(key => {
        if (data[key].length > 0) {
            const csvContent = convertToCSV(data[key]);
            downloadFile(csvContent, `${key}.csv`, 'text/csv');
        }
    });
}

// Export to JSON
function exportToJSON(data) {
    const jsonContent = JSON.stringify(data, null, 2);
    downloadFile(jsonContent, 'financial_data.json', 'application/json');
}

// Export to Excel (simplified)
function exportToExcel(data) {
    // This is a simplified version - in real app use a library like SheetJS
    alert('تصدير Excel يتطلب مكتبة إضافية. استخدم CSV أو JSON بدلاً من ذلك.');
}

// Download file
function downloadFile(content, filename, contentType) {
    const blob = new Blob([content], { type: contentType });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    window.URL.revokeObjectURL(url);
}

// Validate data
function validateData() {
    const validationResults = {
        valid: 0,
        warnings: 0,
        errors: 0,
        messages: []
    };
    
    // Validate accounts
    const accountIds = new Set(currentData.accounts.map(a => a.account_id));
    currentData.balanceSheet.forEach(item => {
        if (!accountIds.has(item.account_id)) {
            validationResults.errors++;
            validationResults.messages.push(`حساب غير موجود: ${item.account_id}`);
        }
    });
    
    // Validate dates
    [...currentData.balanceSheet, ...currentData.incomeStatement, ...currentData.cashFlow, ...currentData.kpis].forEach(item => {
        const date = new Date(item.report_date);
        if (isNaN(date.getTime())) {
            validationResults.errors++;
            validationResults.messages.push(`تاريخ غير صالح: ${item.report_date}`);
        }
    });
    
    // Validate amounts
    [...currentData.balanceSheet, ...currentData.incomeStatement, ...currentData.cashFlow, ...currentData.kpis].forEach(item => {
        const amountFields = ['balance', 'amount', 'revenue', 'net_income', 'operating_activities', 'investing_activities', 'financing_activities'];
        amountFields.forEach(field => {
            if (item[field] && isNaN(parseFloat(item[field]))) {
                validationResults.warnings++;
                validationResults.messages.push(`مبلغ غير صالح في ${field}: ${item[field]}`);
            }
        });
    });
    
    // Update UI
    document.getElementById('validRecords').textContent = validationResults.valid;
    document.getElementById('warningRecords').textContent = validationResults.warnings;
    document.getElementById('errorRecords').textContent = validationResults.errors;
    
    // Show validation results
    const resultsDiv = document.getElementById('validationResults');
    const list = document.getElementById('validationList');
    list.innerHTML = '';
    
    validationResults.messages.forEach(message => {
        const li = document.createElement('li');
        li.className = 'list-group-item';
        li.textContent = message;
        list.appendChild(li);
    });
    
    resultsDiv.style.display = 'block';
}

// Create backup
function createBackup() {
    const backupData = {
        timestamp: new Date().toISOString(),
        accounts: currentData.accounts,
        balanceSheet: currentData.balanceSheet,
        incomeStatement: currentData.incomeStatement,
        cashFlow: currentData.cashFlow,
        kpis: currentData.kpis
    };
    
    const backupContent = JSON.stringify(backupData, null, 2);
    downloadFile(backupContent, `financial_backup_${new Date().toISOString().split('T')[0]}.json`, 'application/json');
}

// Restore backup
function restoreBackup() {
    const fileInput = document.getElementById('backupFile');
    const file = fileInput.files[0];
    
    if (!file) {
        alert('الرجاء اختيار ملف النسخة الاحتياطية');
        return;
    }
    
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const backupData = JSON.parse(e.target.result);
            
            // Validate backup structure
            if (!backupData.accounts || !backupData.balanceSheet) {
                alert('ملف النسخة الاحتياطية غير صالح');
                return;
            }
            
            // Restore data
            currentData = {
                accounts: backupData.accounts,
                balanceSheet: backupData.balanceSheet,
                incomeStatement: backupData.incomeStatement,
                cashFlow: backupData.cashFlow,
                kpis: backupData.kpis
            };
            
            // Save restored data
            saveRestoredData();
            
            alert('تم استعادة البيانات بنجاح');
            location.reload();
        } catch (error) {
            alert('خطأ في استعادة البيانات: ' + error.message);
        }
    };
    
    reader.readAsText(file);
}

// Save restored data
function saveRestoredData() {
    // In a real application, this would save to server
    Object.keys(currentData).forEach(key => {
        if (currentData[key].length > 0) {
            const csvContent = convertToCSV(currentData[key]);
            console.log(`Would save ${key}.csv:`, csvContent);
        }
    });
}

// Update data summary
function updateDataSummary() {
    const totalAccounts = currentData.accounts.length;
    const totalTransactions = currentData.balanceSheet.length + currentData.incomeStatement.length;
    
    // Calculate date range
    const allDates = [
        ...currentData.balanceSheet.map(item => new Date(item.report_date)),
        ...currentData.incomeStatement.map(item => new Date(item.report_date)),
        ...currentData.cashFlow.map(item => new Date(item.report_date)),
        ...currentData.kpis.map(item => new Date(item.report_date))
    ];
    
    const minDate = new Date(Math.min(...allDates));
    const maxDate = new Date(Math.max(...allDates));
    const dateRange = Math.ceil((maxDate - minDate) / (1000 * 60 * 60 * 24));
    
    document.getElementById('totalAccounts').textContent = totalAccounts;
    document.getElementById('totalTransactions').textContent = totalTransactions;
    document.getElementById('dateRangeSpan').textContent = `${dateRange} يوم`;
    document.getElementById('lastUpdate').textContent = new Date().toLocaleDateString('ar-SA');
}

// Setup event listeners
function setupEventListeners() {
    document.getElementById('importForm').addEventListener('submit', handleImport);
}